# EVEREST – A világ tetején

Magyar nyelvű, interaktív Everest-atlasz. A **Felfedezés 3D-ben** gomb megnyitja a forgatható Himalája-terepet. A **Tárlatvezetés** végigjárja a déli útvonal helyszíneit, majd megnyitja a tízkérdéses kvízt.

## Indítás

Szükséges a Node.js 22.12 vagy újabb, az npm és egy korszerű böngésző. A 3D-hez WebGL 2 kell. A letöltött ZIP kibontása után nyiss terminált a projekt könyvtárában.

```sh
npm ci
npm run dev
```

A terminálban megjelenő helyi címet nyisd meg. A domborzat, a fotók és a betűtípusok a projekt részei.

## Használat

- **3D.** húzással forgatás, görgetéssel vagy csippentéssel nagyítás. A terepre lépve billentyűzettel a bal/jobb nyíl forgat, a plusz és mínusz nagyít vagy kicsinyít, a 0 áttekintő nézetre vált.
- **Magassági profil.** a táborok, a halálzóna és a csúcs kiválasztása, valamint a helyszínjegyzék megnyitása.
- **Légkör.** válassz magasságot a csúszkán, vagy ugorj egy tábor magasságára.
- **Tárlatvezetés.** szünet, folytatás, előző és következő fejezet, valamint ugrás bármely fejezetre. A befejező fejezet után megjelenik a kvíz. Az külön a Beállítások menüből is indítható.
- **Beállítások.** három grafikai minőség, az útvonal és a csúcsnevek megjelenítése, választható szélhang és háttérzene. A hang felhasználói műveletre indul.

## Ellenőrzés és kiadás

```sh
npm run test
npm run build
npm run preview
```

A statikus kiadás a `dist/` könyvtárban található. Az `npm run dev` és az `npm run build` automatikusan összeállítja a weboldalról is letölthető forráscsomagot.

## Adatok és licencek

A helyi domborzat a Mapzen / AWS Terrain Tiles 13-as nagyítási szintjének 513 × 513 mintából készített magasságrácsa. A tágabb Himalája-környezet 10-es nagyítási szinten készült. Az SRTM alapadatok az U.S. Geological Survey jóvoltából állnak rendelkezésre. A magasságrácsok little-endian, 16 bites, méterben tárolt adatok. A 3D látvány 1,14-szeres függőleges kiemelést használ. A rács felbontása miatt a felszín csúcsmintái eltérhetnek a hivatalos értékektől. A helyszínek, a táborok és a déli útvonal helyzete tájékoztató. A sátrakat és imazászlókat felnagyítva jeleníti meg.

A légköri adatok a tengerszinttől 11 km-ig alkalmazható standard troposzféramodellből származnak, és oktatási célúak. A nyitópanoráma generált illusztráció. A helyszínek és a múzeum forrásolt Wikimedia Commons-fényképeket használ.

- [AWS Open Data Registry · Terrain Tiles](https://registry.opendata.aws/terrain-tiles/)
- [Tilezen / Mapzen · domborzati adatok forrásai](https://github.com/tilezen/joerd/blob/master/docs/attribution.md)
- A fotók szerzői, licencei és eredeti fájljai a `public/kepek/attribution.json` állományban szerepelnek.
- Az Inter és Barlow Condensed SIL Open Font License fájljai a `public/betuk/` könyvtárban találhatók.

A domborzat előállítása megismételhető a `scripts/terrain.py` szkripttel Python 3 és Pillow használatával. A normál futtatáshoz ezt a lépést ki lehet hagyni.

## Technológia

React, TypeScript, Vite, Three.js, React Three Fiber, Drei, Tailwind CSS és Framer Motion.
