import { useEffect, useRef, useState } from 'react'

type AudioChannels = {
  context: AudioContext
  wind: GainNode
  music: GainNode
}

function buildAudio() {
  const context = new AudioContext()
  const length = context.sampleRate * 6
  const buffer = context.createBuffer(1, length, context.sampleRate)
  const samples = buffer.getChannelData(0)
  let last = 0
  for (let i = 0; i < samples.length; i++) {
    last = (last + (Math.random() - 0.5) * .042) / 1.032
    const taper = Math.min(1, i / 1200, (length - i - 1) / 1200)
    samples[i] = last * taper
  }

  const noise = context.createBufferSource()
  const windFilter = context.createBiquadFilter()
  const wind = context.createGain()
  wind.gain.value = 0
  windFilter.type = 'lowpass'
  windFilter.frequency.value = 400
  noise.buffer = buffer
  noise.loop = true
  noise.connect(windFilter).connect(wind).connect(context.destination)
  noise.start()

  const music = context.createGain()
  const softness = context.createBiquadFilter()
  softness.type = 'lowpass'
  softness.frequency.value = 620
  music.gain.value = 0
  softness.connect(music).connect(context.destination)
  for (const [index, frequency] of [65.406, 98, 130.813, 164.814, 196].entries()) {
    const voice = context.createOscillator()
    const volume = context.createGain()
    const tremolo = context.createOscillator()
    const tremoloDepth = context.createGain()
    voice.type = index === 0 ? 'sine' : 'triangle'
    voice.frequency.value = frequency
    voice.detune.value = index % 2 ? -4 : 3
    volume.gain.value = 0.20 - index * .026
    tremolo.frequency.value = 0.065 + index * .019
    tremoloDepth.gain.value = .035
    tremolo.connect(tremoloDepth).connect(volume.gain)
    voice.connect(volume).connect(softness)
    voice.start()
    tremolo.start()
  }

  return { context, wind, music }
}
export function useAmbientAudio() {
  const channels = useRef<AudioChannels | null>(null)
  const [wind, setWind] = useState(false)
  const [music, setMusic] = useState(false)
  const [error, setError] = useState(false)
  const enabled = wind || music
  const lastEnabled = useRef({ wind: true, music: false })
  const version = useRef(0)

  async function setSound(nextWind: boolean, nextMusic: boolean) {
    const attempt = ++version.current
    try {
      if ((nextWind || nextMusic) && !channels.current) channels.current = buildAudio()
      if (!channels.current) return
      const { context, wind: windGain, music: musicGain } = channels.current
      if (context.state === 'suspended') await context.resume()
      if (attempt !== version.current) return
      const now = context.currentTime
      windGain.gain.setTargetAtTime(nextWind ? .53 : 0, now, .18)
      musicGain.gain.setTargetAtTime(nextMusic ? .12 : 0, now, .26)
      if (nextWind || nextMusic) lastEnabled.current = { wind: nextWind, music: nextMusic }
      setWind(nextWind)
      setMusic(nextMusic)
      setError(false)
    } catch {
      setError(true)
    }
  }

  useEffect(() => () => { void channels.current?.context.close().catch(() => {}) }, [])
  return {
    wind, music, enabled, error,
    setWind: (value: boolean) => { void setSound(value, music) },
    setMusic: (value: boolean) => { void setSound(wind, value) },
    toggle: () => { void (enabled ? setSound(false, false) : setSound(lastEnabled.current.wind, lastEnabled.current.music)) },
  }
}
