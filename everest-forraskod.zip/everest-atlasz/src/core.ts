export const SUMMIT = 8848.86
export const SEA_PRESSURE = 101.325
export const OXYGEN_FRACTION = 0.2095

export const metres = (value: number, digits = 0) =>
  new Intl.NumberFormat('hu-HU', {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(value)

export const views = ['explore', 'air', 'museum', 'compare'] as const
export type View = typeof views[number]
export type Quality = 'eco' | 'balanced' | 'high'
export type Geo = { lat: number; lon: number }

export interface Place {
  id: string
  name: string
  short: string
  altitude: number
  kind: 'peak' | 'camp' | 'ice' | 'landmark'
  geo: Geo
  photo: string
  description: string
  fact: string
  camera: { bearing: number; distance: number; height: number }
  photoPoint?: [number, number]
}
const stop = (id: string, name: string, short: string, altitude: number, kind: Place['kind'],
  lat: number, lon: number, photo: string, description: string, fact: string,
  bearing: number, distance: number, height: number, photoPoint?: [number, number]): Place =>
  ({ id, name, short, altitude, kind, geo: { lat, lon }, photo, description, fact, camera: { bearing, distance, height }, photoPoint })

export const places: Place[] = [
  stop('summit', 'Everest-csúcs', 'Everest-csúcs', SUMMIT, 'peak', 27.98812, 86.92498, 'csucs',
    'Nepál és Kína határán emelkedik a Föld legmagasabb tengerszint feletti pontja. A két ország 2020-ban közösen jelentette be a hófelszínig mért 8848,86 méteres magasságot.',
    'A hegy nepáli neve Szágarmáthá, tibeti neve Csomolungma.',
    223, 3.2, 1.15, [66.7, 21.5]),
  stop('hillary', 'Hillary-lépcső', 'Hillary-lépcső', 8790, 'landmark', 27.98766, 86.92537, 'lepcso',
    'A délkeleti gerinc történelmi sziklaakadálya a déli mellékcsúcs és a főcsúcs között állt. Az archív fényképen az egykori sziklaalakzat látható.',
    'A 2015-ös nepáli földrengés után eltértek a beszámolók arról, mennyire változott meg a lépcső.',
    156, 1.22, 0.65),
  stop('zone', 'Halálzóna', 'Halálzóna', 8000, 'landmark', 27.97644, 86.92815, 'hegy',
    'A hegymászásban nagyjából 8000 méter felett nevezik halálzónának a rendkívül alacsony légnyomású tartományt.',
    'Az oxigén aránya közel 21% marad. A csökkenő légnyomás miatt egy belégzéssel kevesebb oxigén jut a tüdőbe.',
    170, 2.1, 1.1),
  stop('col', 'Déli-nyereg · 4. tábor', '4. tábor', 7900, 'camp', 27.9718, 86.9296, 'nyereg',
    'Kopár, kitett átjáró az Everest és a Lhotse között. A klasszikus nepáli útvonal legmagasabb táborát a nyeregben állítják fel.',
    'A két hegy közti mélyedésben az erős szél a hófelszínt is folyamatosan átrendezi.',
    166, 2.07, 1.02, [80.5, 40]),
  stop('lhotse', 'Lhotse-fal · 3. tábor', '3. tábor', 7200, 'camp', 27.97305, 86.91985, 'lhotsze',
    'A Lhotse nyugati oldalán húzódó meredek, jeges lejtő a Csend völgyéből a magaslati nyereg felé vezet. A 3. tábor a fal különböző pontjain állhat.',
    'A Lhotse 8516 méteres, így az Everest közvetlen szomszédja egyben a Föld negyedik legmagasabb hegye.',
    270, 1.92, 0.8),
  stop('camp2', '2. tábor', '2. tábor', 6400, 'camp', 27.97775, 86.89915, 'cwm',
    'Az előretolt tábor a gleccsermedence felső részén, a Lhotse-fal alatt helyezkedik el. Számos déli expedíció innen folytatja útját a magasabb táborok felé.',
    'A belső medencét az Everest, a Lhotse és a Nuptse falai szegélyezik, amelyekről visszaverődhet a napsugárzás.',
    298, 1.85, 1.0, [71.5, 62.5]),
  stop('cwm', 'Western Cwm · a Csend völgye', 'Csend völgye', 6200, 'ice', 27.98352, 86.88653, 'cwm',
    'Széles, gleccserrel kitöltött medence az Everest délnyugati oldalán. Innen nyílik rátekintés a Lhotse falára és a környező nyolcezres csúcsokra.',
    'A walesi cwm kifejezés hegyekkel körbezárt völgyet jelöl.',
    281, 3.1, 1.25),
  stop('camp1', '1. tábor', '1. tábor', 6065, 'camp', 27.9861, 86.8790, 'jegeses',
    'A déli útvonal első magaslati tábora a Khumbu-jégesés fölötti gleccserszakaszon. Jég és hó veszi körül.',
    'A táborok elhelyezkedése évszakonként és expedíciónként változik. A magasságuk ezért közelítő érték.',
    310, 1.5, 0.73),
  stop('icefall', 'Khumbu-jégesés', 'Khumbu-jégesés', 5600, 'ice', 27.9983, 86.8691, 'jegeses',
    'A Khumbu-gleccser meredek, töredezett szakaszán jégtornyok és hasadékok alakulnak ki, ahogy a jég egy szűkebb szakasz felé áramlik.',
    'A jég mozgása miatt egy-egy hasadék alakja és helyzete idővel megváltozik.',
    295, 1.8, 0.95, [57, 65.9]),
  stop('base', 'Nepáli alaptábor', 'Alaptábor', 5364, 'camp', 28.00256, 86.85271, 'alaptabor',
    'A déli expedíciók kiindulóbázisa a Khumbu-gleccser törmelékkel borított, oldalvölgyi részén, többnapi gyalogútra a legközelebbi közúttól.',
    'Az alaptábor építményei szezonálisak. A 3D-s sátrak a helyszín felismerhetőségét segítik.',
    284, 1.28, 0.62, [49.5, 75]),
  stop('glacier', 'Khumbu-gleccser', 'Khumbu-gleccser', 5200, 'ice', 27.9761, 86.8405, 'gleccser',
    'A gleccser az Everest magasabb lejtőiről a Khumbu-völgy felé folyik. Alsó részén a jég fölött vastag kőtörmelék is felhalmozódik.',
    'A törmelék eltérően hat az olvadásra. Egy vékony réteg gyorsíthatja, egy vastag réteg szigetelheti a jeget.',
    235, 4.15, 1.65),
  stop('memorial', 'Thukla-hágó · emlékhelyek', 'Thukla-hágó', 4830, 'landmark', 27.9285, 86.8148, 'emlek',
    'A Thukla-hágó kőből rakott emlékhelyei a környező hegyekben elhunyt embereknek állítanak emléket. A színes buddhista imazászlók a helyi vallási élet részei.',
    'A hagyomány szerint a szél hordozza tovább az imazászlók üzenetét.',
    210, 1.42, 0.75),
]

export const placeById = Object.fromEntries(places.map(place => [place.id, place])) as Record<string, Place>
export const elevationStops = ['summit', 'zone', 'col', 'lhotse', 'camp2', 'camp1', 'base']
export const route = ['base', 'icefall', 'camp1', 'cwm', 'camp2', 'lhotse', 'col', 'zone', 'hillary', 'summit']

export const neighboringPeaks = [
  { name: 'Lhotse', altitude: 8516, geo: { lat: 27.9617, lon: 86.933 } },
  { name: 'Nuptse', altitude: 7861, geo: { lat: 27.966, lon: 86.8895 } },
  { name: 'Pumori', altitude: 7161, geo: { lat: 28.0153, lon: 86.8282 } },
  { name: 'Csangtse', altitude: 7543, geo: { lat: 28.0244, lon: 86.914 } },
]

export const weatherPresets = [
  { id: 'dawn', name: 'Napfelkelte', sky: '#355779', horizon: '#f19b7b', sun: '#ffd2ad', fog: '#b5a1bb', haze: 0.018, intensity: 2.55, ambient: 1.18, sunPosition: [-36, 16, 13], flakes: 0 },
  { id: 'day', name: 'Nappal', sky: '#152f51', horizon: '#95bad6', sun: '#f1f6ff', fog: '#8aaed0', haze: 0.010, intensity: 3.1, ambient: 1.36, sunPosition: [-33, 41, 27], flakes: 0 },
  { id: 'dusk', name: 'Naplemente', sky: '#252644', horizon: '#e88966', sun: '#ffb792', fog: '#a87385', haze: 0.017, intensity: 2.65, ambient: 0.82, sunPosition: [36, 13, -21], flakes: 0 },
  { id: 'night', name: 'Éjszaka', sky: '#030815', horizon: '#172b49', sun: '#9fbfff', fog: '#1c2d4a', haze: 0.014, intensity: 0.78, ambient: 0.45, sunPosition: [21, 37, 7], flakes: 0 },
  { id: 'storm', name: 'Hóvihar', sky: '#283c50', horizon: '#70869b', sun: '#bdccda', fog: '#7d90a3', haze: 0.088, intensity: 1.18, ambient: 1.08, sunPosition: [-24, 42, 31], flakes: 1 },
  { id: 'fog', name: 'Sűrű köd', sky: '#536d80', horizon: '#a1b7c5', sun: '#d1e0e9', fog: '#b0c3cf', haze: 0.18, intensity: 0.85, ambient: 1.25, sunPosition: [-24, 42, 31], flakes: 0 },
] as const
export type Weather = typeof weatherPresets[number]
export type WeatherId = Weather['id']

export const qualityNames: Record<Quality, string> = { eco: 'Takarékos', balanced: 'Kiegyensúlyozott', high: 'Magas' }

export function atmosphere(altitude: number) {
  const h = Math.max(0, Math.min(11000, altitude))
  const kelvin = 288.15 - 0.0065 * h
  const pressure = SEA_PRESSURE * (kelvin / 288.15) ** 5.25588
  const oxygen = pressure * OXYGEN_FRACTION
  return { temperature: kelvin - 273.15, pressure, oxygen, relativePressure: pressure / SEA_PRESSURE }
}
export function altitudeBand(altitude: number) {
  if (altitude >= 8000) return {
    title: 'Halálzóna',
    body: 'Itt a rendelkezésre álló oxigén súlyosan korlátozott. A szél és a hideg együtt gyorsíthatja a hővesztést, a ritka levegő pedig a gondolkodást és a mozgást is megnehezíti.',
  }
  if (altitude >= 5500) return {
    title: 'Szélsőséges magasság',
    body: 'A szervezet gyorsabb légzéssel reagálhat a kisebb oxigén-résznyomásra. A magas hegyen a hőmérséklet, a szél és a látótávolság rövid idő alatt változhat.',
  }
  if (altitude >= 2500) return {
    title: 'Ritkább levegő',
    body: 'Magasabbra érve a gyorsabb légzés mellett fejfájás és fáradtság is jelentkezhet. A légnyomás és az oxigén résznyomása együtt csökken.',
  }
  return {
    title: 'Tengerszint és az alsó légkör',
    body: 'A levegő fölöttünk lévő tömege adja a légnyomás nagy részét. Tengerszinten a száraz levegő oxigénaránya közel 21%.',
  }
}

export const comparisons = [
  { id: 'eiffel', name: 'Eiffel-torony', height: 330, color: '#e4af78', kind: 'Építmény', fact: 'A párizsi torony magassága antennával együtt.' },
  { id: 'burj', name: 'Burj Khalifa', height: 828, color: '#ad9af7', kind: 'Építmény', fact: 'A dubaji felhőkarcoló magassága a talapzatától a csúcsáig.' },
  { id: 'moldoveanu', name: 'Moldoveanu-csúcs', height: 2544, color: '#74d9ae', kind: 'Hegycsúcs', fact: 'Románia legmagasabb pontja a Fogarasi-havasokban.' },
  { id: 'blanc', name: 'Mont Blanc', height: 4806, color: '#b5e8fc', kind: 'Hegycsúcs', fact: 'Az Alpok legmagasabb csúcsa. A 2023-ban mért, kerekített hófelszíni magasság.' },
  { id: 'everest', name: 'Everest', height: SUMMIT, color: '#55e6fb', kind: 'Hegycsúcs', fact: 'Nepál és Kína 2020-ban megállapított, hófelszínig mért értéke.' },
  { id: 'flight', name: 'Utasszállító', height: 11000, color: '#f4dc9b', kind: 'Utazómagasság', fact: 'Szemléltető érték a hosszabb utak nagyjából 10–12 km-es utazómagasságából.' },
] as const
export type ComparisonId = typeof comparisons[number]['id']

export const timeline = [
  { year: '1921', title: 'Felderítés a hegy északi oldalán', photo: 'csucs', text: 'A brit felderítő expedíció Tibet felől feltérképezte az Everest megközelítésének lehetőségeit. A munkában helyi vezetők és teherhordók működtek közre.' },
  { year: '1924', title: 'Mallory és Irvine eltűnése', photo: 'hegy', text: 'George Mallory és Andrew Irvine a csúcs felé tartva eltűnt. A rendelkezésre álló bizonyítékok alapján nem tudjuk, milyen magasra jutottak.' },
  { year: '1953', title: 'Az első igazolt csúcselérés', photo: '1953', text: 'Május 29-én Tenzing Norgay és Edmund Hillary elérte a csúcsot. A John Hunt vezette expedíció a mászók, hegyi vezetők és a felszerelést a táborokhoz szállító csapatok közös munkájára épült.' },
  { year: '1975', title: 'Junko Tabei a csúcson', photo: 'csucs', text: 'A japán Junko Tabei május 16-án, Ang Cering serpával együtt első nőként érte el az Everest csúcsát.' },
  { year: '1978', title: 'Kiegészítő oxigén nélkül', photo: 'nyereg', text: 'Reinhold Messner és Peter Habeler elsőként jutott fel a csúcsra palackos oxigén használata nélkül.' },
  { year: '1979', title: 'A Szágarmáthá a világörökség része', photo: 'zaszlo', text: 'Az UNESCO felvette a Szágarmáthá Nemzeti Parkot a világörökségi listára. A hegyvidék természeti örökségéhez a Khumbu települései, erdei, gleccserei és a serpa kultúra is szorosan kapcsolódnak.' },
  { year: '2020', title: 'Közös magasságmérés', photo: 'hegy', text: 'Nepál és Kína pontosított geodéziai mérések alapján egyezett meg a csúcs 8848,86 m-es, hófelszínig mért magasságában.' },
]

export const exhibits = [
  {
    id: 'culture', label: 'Serpa kultúra', title: 'A Khumbu közösségei', photo: 'zaszlo',
    paragraphs: [
      'A serpák a Himalája tibeti eredetű népcsoportja. A Khumbu településeinek mindennapi életében a tibeti buddhizmus, a kolostorok, a mezőgazdaság és a kereskedelem is jelen van.',
      'Az expedíciók során serpa hegyivezetők, szervezők és magaslati munkások tervezték és biztosították az útvonalat, szállították a felszerelést, és csúcskísérleteket vezettek. Tenzing Norgay 1953-ban elsőként ért fel igazoltan Edmund Hillaryvel.',
    ],
  },
  {
    id: 'ice', label: 'Gleccserek és védelem', title: 'Egy jégből formált táj', photo: 'gleccser',
    paragraphs: [
      'A műholdak és a terepi mérések a Himalája számos gleccserén hosszú távú tömegvesztést mutatnak. A Khumbu-gleccseren a törmelékréteg, a jégfalak és a felszíni tavak együtt alakítják az olvadás mintázatát.',
      'A Szágarmáthá Nemzeti Park a hegyvidék élőhelyeit és kulturális örökségét védi. A helyi szervezetek hulladékgyűjtéssel és az expedíciók környezeti terheinek mérséklésével is foglalkoznak.',
    ],
  },
] as const

export const chapters = [
  { place: 'memorial', title: 'A Khumbu kapuja', duration: 10500 },
  { place: 'glacier', title: 'A jég folyója', duration: 10000 },
  { place: 'base', title: 'Az expedíció kezdete', duration: 10500 },
  { place: 'icefall', title: 'Jégtornyok között', duration: 10000 },
  { place: 'camp1', title: 'Az első magaslati tábor', duration: 9000 },
  { place: 'cwm', title: 'A Csend völgye', duration: 9500 },
  { place: 'camp2', title: 'A gleccsermedence felső tábora', duration: 9000 },
  { place: 'lhotse', title: 'A Lhotse fala', duration: 11000 },
  { place: 'col', title: 'A Déli-nyereg', duration: 10500 },
  { place: 'zone', title: 'A halálzóna', duration: 10500 },
  { place: 'hillary', title: 'A délkeleti gerinc', duration: 10000 },
  { place: 'summit', title: 'A világ tetején', duration: 12000 },
] as const

export const questions = [
  { question: 'Milyen magas az Everest a 2020-ban bejelentett mérés szerint?', options: ['8516 m', '8848,86 m', '8900 m'], correct: 1, explanation: 'Nepál és Kína 8848,86 méteres, hófelszínig mért magasságot jelentett be.' },
  { question: 'Kik érték el először igazoltan az Everest csúcsát?', options: ['Mallory és Irvine', 'Messner és Habeler', 'Tenzing Norgay és Edmund Hillary'], correct: 2, explanation: 'Tenzing Norgay és Edmund Hillary 1953. május 29-én jutott fel.' },
  { question: 'Mi a Western Cwm magyar neve?', options: ['A Csend völgye', 'A Déli-nyereg', 'A Khumbu-jégesés'], correct: 0, explanation: 'A walesi cwm szó hegyek által körülvett völgyet jelöl.' },
  { question: 'Körülbelül hol kezdődik a halálzóna?', options: ['5000 m', '8000 m', '10 000 m'], correct: 1, explanation: 'A hegymászásban nagyjából 8000 métertől használják ezt a fogalmat.' },
  { question: 'Mi csökken a magasság növekedésével?', options: ['A levegő oxigénaránya', 'A hegy szélessége minden ponton', 'A légnyomás és az oxigén résznyomása'], correct: 2, explanation: 'A levegő oxigénaránya továbbra is közel 21%, az össznyomás viszont alacsonyabb.' },
  { question: 'Mi alakítja át folyamatosan a Khumbu-jégesés felszínét?', options: ['A gleccser mozgása', 'A Föld mágneses tere', 'Az óceán árapálya'], correct: 0, explanation: 'Az áramló jég a meredek szakaszon megreped. Hasadékok és jégtornyok jönnek létre.' },
  { question: 'Melyik két hegy között fekszik a Déli-nyereg?', options: ['Everest és Pumori', 'Everest és Lhotse', 'Nuptse és Makalu'], correct: 1, explanation: 'A Déli-nyereg összeköti az Everestet a szomszédos Lhotséval.' },
  { question: 'Ki volt az első nő az Everest csúcsán?', options: ['Wanda Rutkiewicz', 'Junko Tabei', 'Pasang Lhamu Sherpa'], correct: 1, explanation: 'Junko Tabei 1975-ben, Ang Cering serpa társaságában ért fel.' },
  { question: 'Mire emlékeztetnek a Thukla-hágó kőemlékhelyei?', options: ['A hegyekben elhunyt emberekre', 'A nemzeti park mérési pontjaira', 'Ősi országhatárokra'], correct: 0, explanation: 'A kőből rakott emlékhelyek a környék hegyeiben elhunyt emberek emlékét őrzik.' },
  { question: 'A bemutatott magasságok közül melyik van az Everest csúcsa felett?', options: ['A Mont Blanc csúcsa', 'A Burj Khalifa teteje', 'A 11 km-en repülő utasszállító'], correct: 2, explanation: 'A 11 000 méteres utazómagasság nagyjából 2151 méterrel van a csúcs fölött.' },
] as const

export type TourState = { chapter: number; elapsed: number; playing: boolean; finished: boolean }
export const idleTour: TourState = { chapter: -1, elapsed: 0, playing: false, finished: false }
export type TourAction =
  | { type: 'start' | 'close' | 'toggle' | 'pause' }
  | { type: 'seek'; index: number }
  | { type: 'tick'; delta: number }

export function tourReducer(state: TourState, action: TourAction): TourState {
  switch (action.type) {
    case 'start': return { chapter: 0, elapsed: 0, playing: true, finished: false }
    case 'close': return idleTour
    case 'toggle': return state.chapter < 0 ? state : { ...state, playing: !state.playing }
    case 'pause': return state.playing ? { ...state, playing: false } : state
    case 'seek':
      if (state.chapter < 0 || action.index < 0) return state
      if (action.index >= chapters.length) return { ...idleTour, finished: true }
      return { ...state, chapter: action.index, elapsed: 0 }
    case 'tick': {
      if (!state.playing || state.chapter < 0) return state
      const elapsed = state.elapsed + Math.max(0, action.delta)
      if (elapsed < chapters[state.chapter].duration) return { ...state, elapsed }
      return tourReducer(state, { type: 'seek', index: state.chapter + 1 })
    }
  }
}

export const scoreQuiz = (answers: readonly (number | null)[]) =>
  questions.reduce((score, question, i) => score + Number(answers[i] === question.correct), 0)

export const sources = [
  { title: 'Britannica · Mount Everest', link: 'https://www.britannica.com/place/Mount-Everest', subject: 'Magasság, földrajz és expedíciótörténet' },
  { title: 'The Himalayan Database', link: 'https://www.himalayandatabase.com/', subject: 'Expedíciók, útvonalak és magaslati táborok' },
  { title: 'Alan Arnette · South Col útvonal', link: 'https://www.alanarnette.com/everest/everestsouthroutes.php', subject: 'A déli táborok közelítő magassága' },
  { title: 'UNESCO · Szágarmáthá Nemzeti Park', link: 'https://whc.unesco.org/en/list/120/', subject: 'Természetvédelem és serpa kultúra' },
  { title: 'ICIMOD · Water, Ice, Society, and Ecosystems', link: 'https://hkh.icimod.org/hi-wise/', subject: 'A Hindukus és a Himalája gleccsereinek változása' },
  { title: 'NASA Glenn · Standard légkör', link: 'https://www.grc.nasa.gov/www/k-12/airplane/atmosmet.html', subject: 'Légnyomás és hőmérséklet szemléltető modellje' },
  { title: 'Eiffel-torony · Magasság és adatok', link: 'https://www.toureiffel.paris/en/the-monument/key-figures', subject: 'Az Eiffel-torony magassága antennával' },
  { title: 'CTBUH · Burj Khalifa', link: 'https://www.skyscrapercenter.com/building/burj-khalifa/3', subject: 'Építészeti magasság' },
  { title: 'Mont Blanc · Mérés 2023', link: 'https://www.reuters.com/world/europe/mont-blanc-shrinks-by-over-two-metres-two-years-french-researchers-2023-10-05/', subject: 'A hófelszínig mért magasság változása' },
  { title: 'Mapzen / AWS · Terrain Tiles', link: 'https://registry.opendata.aws/terrain-tiles/', subject: 'Domborzati minták és adatforrások' },
]
