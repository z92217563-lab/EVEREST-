import { LoaderCircle } from 'lucide-react'

export function LoadingMountain() {
  return <div className="scene-loading" role="status" aria-live="polite">
    <div className="loading-model" aria-hidden="true">
      <div className="loading-orbit" /><i /><i /><i /><i />
    </div>
    <span><LoaderCircle size={17} /> A 3D domborzat betöltése</span>
  </div>
}
