import { useMemo, type CSSProperties, type ReactNode } from 'react'
import {
  ChevronLeft, ChevronRight, CloudFog, CloudSnow, Compass, Crosshair, Flag, Globe2, LocateFixed, MapPin, Maximize2, Minus,
  MoonStar, Mountain, Navigation, Pause, Play, Plus, RotateCcw, Route, Sun, Sunrise, Sunset, Wind, X,
} from 'lucide-react'
import {
  chapters, elevationStops, metres, placeById, places, SUMMIT, weatherPresets,
  type TourState, type WeatherId,
} from './core'
import { innerBounds } from './terrain'
import { AnimatedNumber, asset, IconButton } from './ui'
import type { CameraAction } from './Scene'

export function Profile({ selected, altitude, inAir, onSelect, onIndex }: {
  selected: string; altitude: number; inAir: boolean; onSelect: (id: string) => void; onIndex: () => void
}) {
  const place = placeById[selected]
  const value = inAir ? altitude : place.altitude
  const activeElevation = inAir ? elevationStops.find(id => Math.abs(placeById[id].altitude - altitude) < 1) : selected
  return <aside className="profile glass" aria-label="Magassági profil">
    <div className="profile-top">
      <p className="overline"><Mountain size={15} /> Magassági profil</p>
      <div className="profile-value"><AnimatedNumber value={value} digits={value === SUMMIT ? 2 : 0} /><span className="metre">m</span></div>
      <div className="profile-subtitle"><span className="status-dot" aria-hidden="true" />{inAir ? 'Kiválasztott magasság' : place.name}</div>
    </div>
    <div className="profile-body">
      <div className="profile-scale" aria-hidden="true"><i /></div>
      <div className="profile-stops">
        {elevationStops.map(id => {
          const item = placeById[id]
          const isActive = id === activeElevation
          return <button key={id} type="button" className={'profile-stop' + (isActive ? ' is-active' : '')}
            aria-pressed={isActive} onClick={() => onSelect(id)}>
            <i aria-hidden="true" /><span>{item.short}</span>
            <small>{id === 'zone' ? '8 000+' : id === 'summit' ? metres(item.altitude, 2) : '≈ ' + metres(item.altitude)}</small>
          </button>
        })}
      </div>
    </div>
    <button className="profile-index" type="button" onClick={onIndex}><MapPin size={16} /> Helyszínjegyzék <ChevronRight size={15} /></button>
  </aside>
}
const weatherIcons = [Sunrise, Sun, Sunset, MoonStar, CloudSnow, CloudFog]
export function WeatherDock({ value, onChange }: { value: WeatherId; onChange: (id: WeatherId) => void }) {
  return <div className="weather-dock glass" role="group" aria-label="Időjárási látványvilág">
    <p><Wind size={16} /> Időjárás</p>
    {weatherPresets.map((weather, i) => {
      const Icon = weatherIcons[i]
      const label = weather.id === 'night' ? 'Csillagos éjszaka' : weather.name
      return <button key={weather.id} type="button" onClick={() => onChange(weather.id)} title={label}
        aria-label={label} aria-pressed={weather.id === value} className={weather.id === value ? 'is-active' : ''}>
        <Icon size={18} /><span>{weather.name}</span>
      </button>
    })}
  </div>
}
export function CameraDock({ three, comparable, rotating, onRotate, onCommand, onView }: {
  three: boolean; comparable: boolean; rotating: boolean; onRotate: () => void
  onCommand: (action: CameraAction) => void; onView: (three: boolean) => void
}) {
  return <div className="camera-controls">
    {(three || comparable) && <div className="camera-tools glass" role="group" aria-label="Kameravezérlés">
      <IconButton label="Körbeforgás" aria-pressed={rotating} className={rotating ? 'selected' : ''} onClick={onRotate}><RotateCcw size={17} /></IconButton>
      <i aria-hidden="true" />
      <IconButton label="Nagyítás" onClick={() => onCommand('zoomIn')}><Plus size={19} /></IconButton>
      <IconButton label="Kicsinyítés" onClick={() => onCommand('zoomOut')}><Minus size={19} /></IconButton>
      <IconButton label="Áttekintő kameranézet" onClick={() => onCommand('overview')}><Crosshair size={17} /></IconButton>
    </div>}
    {!comparable && <div className="view-switch glass" role="group" aria-label="Térképnézet">
      <button type="button" aria-pressed={!three} onClick={() => onView(false)}><Mountain size={15} /> <span>Panoráma</span></button>
      <button type="button" aria-pressed={three} onClick={() => onView(true)}><Globe2 size={15} /> <span>3D</span></button>
    </div>}
  </div>
}

function toMap(lat: number, lon: number) {
  return [(lon - innerBounds.west) / (innerBounds.east - innerBounds.west) * 100,
    (innerBounds.north - lat) / (innerBounds.north - innerBounds.south) * 100]
}
export function MiniMap({ active, onOpen }: { active: string; onOpen: () => void }) {
  const mapPosition = toMap(placeById[active].geo.lat, placeById[active].geo.lon)
  return <button className="mini-map glass" type="button" aria-label="Helyszínjegyzék megnyitása a Khumbu-térképről" onClick={onOpen}>
    <img src={asset('atlas/khumbu.webp')} alt="" loading="lazy" />
    <span className="map-north"><Navigation size={13} /> É</span>
    <span className="map-position" style={{ left: mapPosition[0] + '%', top: mapPosition[1] + '%' }} aria-hidden="true" />
    <span className="map-caption"><span>Khumbu-régió</span><Maximize2 size={13} /></span>
  </button>
}

const PANO_POINTS = [
  [49.5, 75], [53.2, 71.5], [57, 65.9], [60.7, 62.5], [65.6, 62], [71.5, 62.5],
  [74.2, 56.7], [77.8, 49], [80.5, 40], [75.5, 36.7], [71.8, 31.1], [69.4, 26.8], [66.7, 21.5],
]
export function Panorama({ weather, markers, route, active, onSelect }: {
  weather: WeatherId; markers: boolean; route: boolean; active: string; onSelect: (id: string) => void
}) {
  const weatherParticles = useMemo(() => Array.from({ length: 76 }, (_, i) => ({
    '--x': ((i * 37.27) % 100) + '%',
    '--y': ((i * 67.73) % 100) + '%',
    '--length': (i % 3 + 1) + 'px',
    '--speed': (4 + i % 9) + 's',
    '--delay': (-i * .41) + 's',
  }) as CSSProperties), [])
  return <>
    {!markers && <><div className="poster-plane" aria-hidden="true"><img className="poster" src={asset('kepek/nyitokep.webp')} alt="" fetchPriority="high" /></div>
    <div className={'panorama-weather weather-' + weather} aria-hidden="true">
      <i /><i />
      {(weather === 'storm' || weather === 'night') && weatherParticles.map((style, i) => <b key={i} style={style} />)}
    </div>
    </>}
    {markers && <div className="poster-plane poster-markers">
      {route && <svg className="poster-route" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <polyline points={PANO_POINTS.map(([x, y]) => x + ',' + y).join(' ')} />
      </svg>}
      {places.filter(place => place.photoPoint).map(place =>
        <button key={place.id} type="button" className={'pano-pin' + (active === place.id ? ' is-selected' : '')}
          aria-label={place.name} title={place.name} style={{ left: place.photoPoint![0] + '%', top: place.photoPoint![1] + '%' }}
          onClick={() => onSelect(place.id)}>
          <span className="pin-dot" aria-hidden="true" /><span className="pin-title">{place.short}</span>
        </button>)}
    </div>}
  </>
}

export function TourBar({ tour, onToggle, onMove, onClose, onSeek }: {
  tour: TourState; onToggle: () => void; onMove: (delta: number) => void; onClose: () => void; onSeek: (chapter: number) => void
}) {
  if (tour.chapter < 0) return null
  const chapter = chapters[tour.chapter]
  const nextLabel = tour.chapter === chapters.length - 1 ? 'Befejezés és kvíz' : 'Következő fejezet'
  const proportion = tour.elapsed / chapter.duration
  return <section className="tour-bar glass" aria-label="Tárlatvezetés vezérlése">
    <div className="tour-progress" aria-hidden="true"><span style={{ width: proportion * 100 + '%' }} /></div>
    <div className="tour-label">
      <Route size={19} />
      <label>
        <span className="sr-only">Fejezet</span>
        <select className="tour-select" value={tour.chapter} onChange={event => onSeek(Number(event.currentTarget.value))}>
          {chapters.map((item, i) => <option key={item.place} value={i}>{i + 1} / {chapters.length} · {item.title}</option>)}
        </select>
      </label>
    </div>
    <div className="tour-buttons">
      <IconButton label="Előző fejezet" disabled={tour.chapter === 0} onClick={() => onMove(-1)}><ChevronLeft size={19} /></IconButton>
      <IconButton label={tour.playing ? 'Tárlatvezetés szüneteltetése' : 'Tárlatvezetés folytatása'} className="selected" onClick={onToggle}>
        {tour.playing ? <Pause size={17} /> : <Play size={17} />}
      </IconButton>
      <IconButton label={nextLabel} onClick={() => onMove(1)}>{tour.chapter === chapters.length - 1 ? <Flag size={16} /> : <ChevronRight size={19} />}</IconButton>
      <IconButton label="Tárlatvezetés bezárása" onClick={onClose}><X size={17} /></IconButton>
    </div>
  </section>
}
export function Coordinates({ children }: { children?: ReactNode }) {
  return <div className="coordinates"><LocateFixed size={15} /> <span>27°59′17″ É</span><i /><span>86°55′30″ K</span>{children}</div>
}
