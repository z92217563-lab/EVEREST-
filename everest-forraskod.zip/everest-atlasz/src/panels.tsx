import { useState, type CSSProperties } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Activity, BookOpen, Box, ChevronDown, Compass, Crosshair, Flag, Info, Landmark, MapPin, Waves, X } from 'lucide-react'
import {
  altitudeBand, atmosphere, comparisons, exhibits, metres, places, SEA_PRESSURE,
  SUMMIT, timeline, type ComparisonId, type Place,
} from './core'
import { AnimatedNumber, IconButton, PanelHeading, Photograph } from './ui'

const panelMotion = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: 8 },
  transition: { duration: 0.22 },
}

export function PlacePanel({ place, onSelect, onClose }: { place: Place; onSelect: (id: string) => void; onClose: () => void }) {
  return <motion.aside {...panelMotion} className="context-panel place-panel glass" aria-label="Helyszín ismertetője">
    <IconButton className="close-button" label="Ismertető bezárása" onClick={onClose}><X size={19} /></IconButton>
    <AnimatePresence mode="wait" initial={false}>
      <motion.div key={place.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.13 }}>
        <Photograph photo={place.photo} eager />
        <div className="panel-content">
          <p className="overline"><MapPin size={15} />{place.id === 'summit' ? metres(place.altitude, 2) : place.id === 'zone' ? '8 000+' : '≈ ' + metres(place.altitude)} m</p>
          <h2>{place.name}</h2>
          <p className="panel-copy">{place.description}</p>
          <div className="fact-box"><Info size={17} /><p>{place.fact}</p></div>
        </div>
      </motion.div>
    </AnimatePresence>
    <div className="place-picker">
      <label htmlFor="place-select">Másik helyszín</label>
      <div className="select-wrap">
        <select id="place-select" value={place.id} onChange={event => onSelect(event.currentTarget.value)}>
          {places.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
        <ChevronDown size={16} aria-hidden="true" />
      </div>
    </div>
  </motion.aside>
}
const graphCoordinates = (altitude: number) => [20 + altitude / SUMMIT * 312, 78 - 61 * atmosphere(altitude).relativePressure]
const graphPath = Array.from({ length: 52 }, (_, i) => {
  const [x, y] = graphCoordinates(i / 51 * SUMMIT)
  return (i === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1)
}).join(' ')

function PressureGraph({ altitude }: { altitude: number }) {
  const [x, y] = graphCoordinates(altitude)
  const reduced = useReducedMotion()
  return <div className="pressure-chart">
    <div className="graph-header"><span>Légnyomás alakulása</span><small>kPa</small></div>
    <svg viewBox="0 0 348 94" role="img" aria-label={'A légnyomás csökkenése a magassággal, ' + metres(atmosphere(altitude).pressure, 1) + ' kilopascal a kijelölt magasságon'}>
      <defs><linearGradient id="pressure-fill" x2="0" y2="1"><stop offset="0%" stopColor="#53e4ff" stopOpacity=".36" /><stop offset="100%" stopColor="#53e4ff" stopOpacity="0" /></linearGradient></defs>
      {[17, 38, 58, 78].map(height => <line key={height} x1="20" x2="332" y1={height} y2={height} stroke="#63829940" />)}
      <path d={graphPath + ' L332,78 L20,78 Z'} fill="url(#pressure-fill)" />
      <path d={graphPath} fill="none" stroke="#67e9fd" strokeWidth="2" />
      <motion.line initial={false} animate={{ x1: x, x2: x, y1: y }} y2="78" stroke="#71ecfc" opacity=".67" strokeDasharray="3 4" transition={{ duration: reduced ? 0 : .19 }} />
      <motion.circle initial={false} animate={{ cx: x, cy: y }} r="4.5" fill="#c2faff" stroke="#32cce6" strokeWidth="2" transition={{ duration: reduced ? 0 : .19 }} />
      <text x="20" y="92">0 m</text><text x="332" y="92" textAnchor="end">8 849 m</text>
    </svg>
  </div>
}
export function AirPanel({ altitude, onChange }: { altitude: number; onChange: (altitude: number) => void }) {
  const level = altitudeBand(altitude)
  const values = atmosphere(altitude)
  return <motion.aside {...panelMotion} className="context-panel education-panel air-panel glass" aria-label="Légköri modell">
    <PanelHeading icon={<Activity size={16} />} eyebrow="Légköri modell">A ritkuló levegő</PanelHeading>
    <div className="altitude-slider">
      <label htmlFor="altitude">Magasság</label>
      <strong><AnimatedNumber value={altitude} digits={altitude === SUMMIT ? 2 : 0} /> m</strong>
      <input id="altitude" type="range" min="0" max="8849" step="1" value={Math.round(altitude)}
        aria-valuetext={metres(altitude, altitude === SUMMIT ? 2 : 0) + ' méter'}
        style={{ '--fill': (altitude / SUMMIT * 100) + '%' } as CSSProperties}
        onChange={event => onChange(Math.min(SUMMIT, Number(event.currentTarget.value)))} />
      <div className="alt-range"><span>Tengerszint</span><span>Everest-csúcs</span></div>
    </div>
    <div className="air-metrics">
      <div><span>Légnyomás</span><strong><AnimatedNumber value={values.pressure} digits={1} /><small> kPa</small></strong></div>
      <div><span>O₂-résznyomás</span><strong><AnimatedNumber value={values.oxygen} digits={1} /><small> kPa</small></strong></div>
      <div><span>Hőmérséklet</span><strong><AnimatedNumber value={values.temperature} digits={1} /><small> °C</small></strong></div>
    </div>
    <PressureGraph altitude={altitude} />
    <div className={'air-effects' + (altitude >= 8000 ? ' extreme' : '')}>
      <strong>{level.title}</strong><p>{level.body}</p>
      <small>A tengerszinti légnyomás {metres(100 * values.pressure / SEA_PRESSURE, 0)}%-a.</small>
    </div>
    <p className="data-note"><Info size={14} /> A standard légkör oktatási modellje. A hegy tényleges időjárása ettől eltér.</p>
  </motion.aside>
}

export function MuseumPanel({ onSources }: { onSources: () => void }) {
  const [mode, setMode] = useState<'expeditions' | 'culture' | 'ice'>('expeditions')
  const [date, setDate] = useState(2)
  const event = timeline[date]
  const exhibit = exhibits.find(item => item.id === mode)
  return <motion.aside {...panelMotion} className="context-panel education-panel museum-panel glass" aria-label="Történelmi múzeum">
    <PanelHeading icon={<Landmark size={16} />} eyebrow="Történelmi múzeum">A hegy és az emberek</PanelHeading>
    <div className="museum-sections" aria-label="Múzeumi témák">
      <button type="button" aria-pressed={mode === 'expeditions'} onClick={() => setMode('expeditions')}><Flag size={15} /> Expedíciók</button>
      {exhibits.map(item => <button key={item.id} type="button" aria-pressed={mode === item.id} onClick={() => setMode(item.id)}>
        {item.id === 'culture' ? <BookOpen size={15} /> : <Waves size={15} />}{item.label}
      </button>)}
    </div>
    {mode === 'expeditions' && <div className="timeline" aria-label="Történelmi idővonal">
      {timeline.map((item, index) => <button key={item.year} type="button" aria-pressed={date === index} onClick={() => setDate(index)}>{item.year}</button>)}
    </div>}
    <AnimatePresence mode="wait" initial={false}>
      <motion.div key={exhibit?.id ?? event.year} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.14 }}>
        <Photograph photo={exhibit?.photo ?? event.photo} eager />
        <div className="museum-copy">
          {!exhibit && <span className="museum-year">{event.year}</span>}
          <h3>{exhibit?.title ?? event.title}</h3>
          {exhibit ? exhibit.paragraphs.map(text => <p key={text}>{text}</p>) : <p>{event.text}</p>}
          {!exhibit && event.year === '1953' && <div className="pioneer-notes">
            <p><strong>Tenzing Norgay</strong> serpa hegymászó, aki már több Himalája-expedíción szerzett tapasztalatot.</p>
            <p><strong>Edmund Hillary</strong> új-zélandi hegymászó, aki később évtizedekig támogatta a nepáli Khumbu közösségeit.</p>
          </div>}
        </div>
      </motion.div>
    </AnimatePresence>
    <button type="button" className="text-button" onClick={onSources}><Info size={15} /> Történelmi források</button>
  </motion.aside>
}

export function ComparePanel({ selected, onSelect, onFocus }: { selected: ComparisonId; onSelect: (id: ComparisonId) => void; onFocus: () => void }) {
  const active = comparisons.find(item => item.id === selected)!
  return <motion.aside {...panelMotion} className="context-panel education-panel comparison-panel glass" aria-label="Magasságok összehasonlítása">
    <PanelHeading icon={<Box size={16} />} eyebrow="Méretarányos 3D">Mekkora az Everest?</PanelHeading>
    <div className="comparison-list">
      {comparisons.map(item => <button key={item.id} type="button" aria-pressed={item.id === selected} onClick={() => onSelect(item.id)} style={{ '--tone': item.color } as CSSProperties}>
        <span><i />{item.name}</span><strong>{metres(item.height, item.id === 'everest' ? 2 : 0)} m</strong>
        <span className="comparison-track"><motion.i initial={false} animate={{ width: (item.height / 11000 * 100) + '%' }} /></span>
      </button>)}
    </div>
    <div className="comparison-fact"><p className="overline">{active.kind}</p><strong>{active.name}</strong><p>{active.fact}</p></div>
    <button type="button" className="secondary-button compact" onClick={onFocus}><Crosshair size={16} /> Közelkép</button>
    <p className="data-note"><Info size={14} /> A hegyek és a repülő adatai tengerszint feletti értékek. A tornyoknál a talapzattól mért magasság látható. A repülő jelképe nagyított.</p>
  </motion.aside>
}

export function SceneGuide({ onIndex }: { onIndex: () => void }) {
  return <div className="scene-guide glass">
    <div><Compass size={18} /><span>Szabad felfedezés</span></div>
    <p>Forgass húzással. Nagyíts görgetéssel vagy csippentéssel.</p>
    <button className="text-button" type="button" onClick={onIndex}><MapPin size={15} /> Helyszínek</button>
  </div>
}
