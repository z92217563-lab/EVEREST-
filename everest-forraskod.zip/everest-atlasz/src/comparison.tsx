import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, Line } from '@react-three/drei'
import * as THREE from 'three'
import { comparisons, metres, type ComparisonId } from './core'

const spacing = [-8.9, -6.3, -3.3, 0, 4.35, 8.8]
export const comparisonPosition = (id: ComparisonId) => {
  const index = comparisons.findIndex(item => item.id === id)
  return { x: spacing[index], height: comparisons[index].height / 1000 }
}

function Eiffel({ height, color }: { height: number; color: string }) {
  const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]]
  const tiers = [0, 0.17, 0.35, 0.56, 0.75, 0.90]
  const radii = [0.192, 0.128, 0.091, 0.064, 0.04, 0.025]
  const tierPoints = tiers.map((heightRatio, i) => corners.map(([x, z]) => [
    radii[i] * x, height * heightRatio, radii[i] * z,
  ] as [number, number, number]))
  return <group scale={[0.38, 1, 0.38]}>
    {tierPoints.map((points, i) => <group key={i}>
      <Line points={[...points, points[0]]} color={color} lineWidth={1.6} />
      {i + 1 < tierPoints.length && points.map((point, j) =>
        <Line key={j} points={[point, tierPoints[i + 1][j], points[(j + 1) % 4]]} color={color} lineWidth={1.3} />)}
    </group>)}
    <mesh position={[0, height * .938, 0]}><cylinderGeometry args={[0.007, 0.018, height * .124, 6]} /><meshStandardMaterial color={color} /></mesh>
    <mesh position={[0, height * .35, 0]}><boxGeometry args={[0.192, 0.009, 0.192]} /><meshStandardMaterial color={color} /></mesh>
  </group>
}
function Burj({ height, color }: { height: number; color: string }) {
  const categories = [
    { to: .23, radius: .087 }, { to: .40, radius: .068 }, { to: .57, radius: .054 },
    { to: .72, radius: .046 }, { to: .80, radius: .028 }, { to: .90, radius: .017 },
    { to: 1, radius: .007 },
  ]
  return <group>
    {categories.map(({ to, radius }, i) => {
      const from = categories[i - 1]?.to ?? 0
      return <mesh key={to} position={[0, (from + to) * height / 2, 0]}>
        <cylinderGeometry args={[radius * .70, radius, (to - from) * height, 6]} />
        <meshStandardMaterial color={color} metalness={0.44} roughness={0.44} />
      </mesh>
    })}
    {[0, 2.094, 4.188].map((angle, i) => <mesh key={angle} position={[Math.cos(angle) * .05, height * .196, Math.sin(angle) * .05]} rotation={[0, angle, 0]}>
      <boxGeometry args={[.093, height * (.4 - i * .04), .037]} /><meshStandardMaterial color={color} metalness={0.28} />
    </mesh>)}
  </group>
}
function Peak({ height, color, width, ridges }: { height: number; color: string; width: number; ridges: number }) {
  const geometry = useMemo(() => {
    const result = new THREE.PlaneGeometry(width * 2, width * 1.55, 44, 44)
    result.rotateX(-Math.PI / 2)
    const positions = result.attributes.position
    const colors: number[] = []
    const top = new THREE.Color(color)
    const base = top.clone().multiplyScalar(.23)
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i) / width
      const z = positions.getZ(i) / (width * .775)
      const radius = Math.hypot(x, z)
      const angle = Math.atan2(z, x)
      const variation = .12 * Math.sin(angle * ridges + .5) + .06 * Math.cos(angle * 3 - radius * 13)
      const slope = Math.max(0, 1 - radius * (1.16 + variation))
      const y = height * Math.pow(slope, 1.12) * (1 - .12 * radius * Math.sin(x * 24 + z * 12))
      positions.setY(i, y)
      const value = Math.min(1, .18 + y / height * .93 + .11 * Math.sin(x * 33 + z * 41) * Math.min(1, radius * 6))
      colors.push(...base.clone().lerp(top, value).toArray())
    }
    result.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
    result.computeVertexNormals()
    return result
  }, [height, color, width, ridges])
  useEffect(() => () => geometry.dispose(), [geometry])
  return <mesh geometry={geometry}><meshStandardMaterial vertexColors transparent={false} roughness={.94} /></mesh>
}
function Airliner({ color, height, reduced }: { color: string; height: number; reduced: boolean }) {
  const model = useRef<THREE.Group>(null)
  useFrame(({ clock }) => {
    if (!model.current || reduced) return
    model.current.rotation.y = -0.5 + Math.sin(clock.elapsedTime * .35) * .22
    model.current.position.x = Math.sin(clock.elapsedTime * .48) * .33
  })
  return <>
    <Line points={[[0, 0, 0], [0, height, 0]]} color={color} lineWidth={1.05} opacity={.75} transparent dashed dashSize={.22} gapSize={.16} />
    <group ref={model} position={[0, height, 0]} rotation={[0, -.5, 0]}>
      <mesh rotation={[0, 0, Math.PI / 2]}><capsuleGeometry args={[.085, .86, 6, 12]} /><meshStandardMaterial color={color} roughness={.31} /></mesh>
      <mesh rotation={[0, Math.PI * .11, 0]}><boxGeometry args={[.16, .035, .96]} /><meshStandardMaterial color={color} roughness={.45} /></mesh>
      <mesh position={[-.39, .015, 0]}><boxGeometry args={[.10, .028, .36]} /><meshStandardMaterial color={color} /></mesh>
      <mesh position={[-.39, .13, 0]} rotation={[0, 0, -.39]}><boxGeometry args={[.109, .19, .031]} /><meshStandardMaterial color={color} /></mesh>
      {[-.2, .2].map(z => <mesh key={z} position={[.09, -.044, z]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[.043, .044, .16, 12]} /><meshStandardMaterial color="#567184" metalness={.4} /></mesh>)}
    </group>
  </>
}
export function ComparisonWorld({ selected, reduced, onSelect }: { selected: ComparisonId; reduced: boolean; onSelect: (id: ComparisonId) => void }) {
  return <>
    <color attach="background" args={['#0a1828']} />
    <fogExp2 attach="fog" args={['#0a1828', 0.016]} />
    <hemisphereLight args={['#ecf4ff', '#23445f', 2.15]} />
    <directionalLight position={[-7, 14, 10]} color="#d0eaff" intensity={2.8} />
    <gridHelper args={[45, 45, '#417d96', '#183951']} position={[0, -.029, 0]} />
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.035, 0]}>
      <planeGeometry args={[80, 80]} /><meshStandardMaterial color="#0c1b29" roughness={1} />
    </mesh>
    {[0, 2, 4, 6, 8, 10].map(height => <group key={height}>
      <Line points={[[-11.25, height, -2.7], [11.4, height, -2.7]]} color="#32829c" transparent opacity={.32} lineWidth={1} dashed gapSize={.17} dashSize={.15} />
      <Html center position={[-11.74, height, -2.7]} style={{ pointerEvents: 'none' }}><span className="grid-height">{height} km</span></Html>
    </group>)}
    {comparisons.map((value, index) => {
      const height = value.height / 1000
      return <group key={value.id} position={[spacing[index], 0, 0]}>
        <group onClick={event => { event.stopPropagation(); onSelect(value.id) }}>
          {value.id === 'eiffel' && <Eiffel height={height} color={value.color} />}
          {value.id === 'burj' && <Burj height={height} color={value.color} />}
          {value.id === 'flight' && <Airliner height={height} color={value.color} reduced={reduced} />}
          {(value.id === 'moldoveanu' || value.id === 'blanc' || value.id === 'everest') &&
            <Peak height={height} color={value.color} width={1.05 + index * .2} ridges={index + 3} />}
        </group>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, .005, 0]}>
          <ringGeometry args={[1.12, 1.18, 44]} />
          <meshBasicMaterial color={value.color} transparent opacity={value.id === selected ? .85 : .18} />
        </mesh>
        <Html center position={[0, height + (index < 2 ? .58 : .43), 0]} zIndexRange={[6, 1]}>
          <button className={'compare-marker' + (value.id === selected ? ' is-selected' : '')} type="button" onClick={() => onSelect(value.id)}>
            <b>{value.name}</b><span style={{ color: value.color }}>{metres(value.height, value.id === 'everest' ? 2 : 0)} m</span>
          </button>
        </Html>
      </group>
    })}
  </>
}
