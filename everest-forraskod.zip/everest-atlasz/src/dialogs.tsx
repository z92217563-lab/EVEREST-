import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Check, ChevronRight, Download, ExternalLink, Flag, Info, MapPin, Medal, Mountain, RotateCcw, X } from 'lucide-react'
import { metres, places, questions, scoreQuiz, sources } from './core'
import { asset, IconButton, photos } from './ui'

export function AtlasDialog({ title, onClose, children, wide = false }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const element = useRef<HTMLDialogElement>(null)
  useEffect(() => {
    const dialog = element.current
    dialog?.showModal()
    return () => dialog?.close()
  }, [])
  return <dialog ref={element} className={'atlas-dialog' + (wide ? ' is-wide' : '')} aria-label={title}
    onCancel={event => { event.preventDefault(); onClose() }}
    onClick={event => {
      if (event.target === event.currentTarget) {
        const bounds = event.currentTarget.getBoundingClientRect()
        if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) onClose()
      }
    }}>
    <IconButton className="close-button" label="Ablak bezárása" onClick={onClose} autoFocus><X size={21} /></IconButton>
    {children}
  </dialog>
}

export function LocationsDialog({ onSelect }: { onSelect: (id: string) => void }) {
  return <>
    <p className="overline"><MapPin size={16} /> Déli útvonal és környéke</p>
    <h2>Helyszínjegyzék</h2>
    <div className="location-grid">
      {places.map(place => <button key={place.id} type="button" onClick={() => onSelect(place.id)}>
        <img src={asset('kepek/' + place.photo + '.webp')} alt="" loading="lazy" />
        <span><strong>{place.name}</strong><small>{place.id === 'summit' ? metres(place.altitude, 2) : place.id === 'zone' ? '8 000+' : '≈ ' + metres(place.altitude)} m</small></span>
        <ChevronRight size={16} />
      </button>)}
    </div>
  </>
}

export function CreditsDialog() {
  return <>
    <p className="overline"><Info size={16} /> Everest-atlasz</p>
    <h2>Források és letöltés</h2>
    <p>A 3D domborzat a Mapzen Terrain Tiles magassági mintáira épül, 1,14-szeres függőleges kiemeléssel. Az SRTM alapadatokat az Amerikai Földtani Szolgálat (USGS) bocsátotta rendelkezésre. A helyszínek és a déli útvonal jelölése közelítő. A sátrak és az imazászlók láthatóságához a modell felnagyítja őket. A nyitópanoráma generált illusztráció.</p>
    <a className="primary-button" download href={asset('everest-forraskod.zip')}><Download size={17} /> Projekt és indítási útmutató</a>
    <h3>Adatok és háttéranyagok</h3>
    <ul className="source-list">
      {sources.map(source => <li key={source.link}><a href={source.link} target="_blank" rel="noreferrer">{source.title}<ExternalLink size={13} /></a><small>{source.subject}</small></li>)}
    </ul>
    <details className="photo-credits">
      <summary>Fényképek és licencek</summary>
      <p>A Commons-fotók átméretezett, WebP-formátumú másolatok. Az alkalmazás megjelenítéskor részben vághatja őket.</p>
      <ul className="source-list">
        {Object.entries(photos).map(([id, photo]) => <li key={id}>
          <a href={photo.source} target="_blank" rel="noreferrer">{photo.caption}<ExternalLink size={13} /></a>
          <small>{photo.creator} · {photo.licenseUrl ? <a href={photo.licenseUrl} target="_blank" rel="noreferrer">{photo.license}</a> : photo.license}</small>
        </li>)}
      </ul>
    </details>
  </>
}
export function QuizDialog({ onClose }: { onClose: () => void }) {
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState<(number | null)[]>(() => questions.map(() => null))
  const [finished, setFinished] = useState(false)
  const heading = useRef<HTMLHeadingElement>(null)
  const answer = answers[index]
  const current = questions[index]
  const score = scoreQuiz(answers)
  useEffect(() => { if (index > 0 || finished) heading.current?.focus() }, [index, finished])
  function choose(option: number) {
    setAnswers(old => old[index] === null ? old.map((value, i) => i === index ? option : value) : old)
  }

  if (finished) return <>
    <p className="overline"><Medal size={17} /> Everest-kvíz · Eredmény</p>
    <h2 ref={heading} tabIndex={-1} className="quiz-result">{score} <span>/ {questions.length} pont</span></h2>
    <p>{score === questions.length ? 'Minden kérdésre helyesen válaszoltál.' : 'A válaszok magyarázatában áttekintheted, mit érdemes felidézni.'}</p>
    <details className="quiz-review"><summary>Válaszok és magyarázatok</summary>
      <ol>{questions.map((question, i) => <li key={question.question}>
        <strong>{question.question}</strong>
        <p>{answers[i] === question.correct ? 'Helyes. ' : 'Helyes válasz · ' + question.options[question.correct] + '. '}{question.explanation}</p>
      </li>)}</ol>
    </details>
    <div className="quiz-actions"><button className="primary-button" type="button" onClick={() => { setIndex(0); setFinished(false); setAnswers(questions.map(() => null)) }}><RotateCcw size={16} /> Újrakezdés</button>
      <button className="secondary-button" type="button" onClick={onClose}><Mountain size={16} /> Vissza az Everestre</button></div>
  </>
  return <>
    <p className="overline"><Flag size={16} /> Everest-kvíz</p>
    <div className="quiz-steps" aria-label={(index + 1) + '. kérdés, összesen ' + questions.length}>
      {questions.map((item, i) => <i key={item.question} className={i <= index ? 'filled' : ''} />)}
    </div>
    <p className="quiz-count">{index + 1} / {questions.length}. kérdés</p>
    <h2 ref={heading} tabIndex={-1}>{current.question}</h2>
    <div className="quiz-options">
      {current.options.map((option, i) => {
        const correct = answer !== null && i === current.correct
        const incorrect = i === answer && !correct
        return <button type="button" key={option} disabled={answer !== null} className={correct ? 'correct' : incorrect ? 'incorrect' : ''} onClick={() => choose(i)}>
          <span>{'ABC'[i]}</span><strong>{option}</strong>{correct && <Check size={18} />}{incorrect && <X size={18} />}
        </button>
      })}
    </div>
    {answer !== null && <div className="quiz-feedback" aria-live="polite">
      <strong>{answer === current.correct ? 'Helyes válasz' : 'A helyes válasz · ' + current.options[current.correct]}</strong>
      <p>{current.explanation}</p>
      <button className="primary-button" type="button" onClick={() => index === questions.length - 1 ? setFinished(true) : setIndex(index + 1)}>
        {index === questions.length - 1 ? 'Eredmény' : 'Következő kérdés'}
      </button>
    </div>}
  </>
}
