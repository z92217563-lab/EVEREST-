import {
  lazy, Suspense, useCallback, useEffect, useReducer, useRef, useState, type KeyboardEvent,
} from 'react'
import { createRoot } from 'react-dom/client'
import { AnimatePresence, motion, MotionConfig, useReducedMotion } from 'framer-motion'
import {
  Activity, BookOpen, Box, ChevronsUp, Compass, Download, Info, Landmark, Layers3, Maximize2,
  Minimize2, MountainSnow, Play, Route, Settings2, Volume2, VolumeX,
} from 'lucide-react'
import {
  chapters, idleTour, placeById, qualityNames, SUMMIT, tourReducer, weatherPresets,
  type ComparisonId, type Quality, type View, type WeatherId,
} from './core'
import { useAmbientAudio } from './audio'
import { CameraDock, Coordinates, MiniMap, Panorama, Profile, TourBar, WeatherDock } from './controls'
import { AirPanel, ComparePanel, MuseumPanel, PlacePanel, SceneGuide } from './panels'
import { AtlasDialog, CreditsDialog, LocationsDialog, QuizDialog } from './dialogs'
import { IconButton } from './ui'
import { LoadingMountain } from './LoadingMountain'
import type { CameraAction, CameraCommand } from './Scene'
import './style.css'

const TerrainScene = lazy(() => import('./Scene'))
const navigation = [
  { view: 'explore', hash: '', label: 'Felfedezés', icon: Compass },
  { view: 'air', hash: '#legkor', label: 'Légkör', icon: Activity },
  { view: 'museum', hash: '#muzeum', label: 'Történelem', icon: Landmark },
  { view: 'compare', hash: '#meretarany', label: 'Összehasonlítás', icon: Layers3 },
] as const

function currentView() {
  return navigation.find(item => item.hash === window.location.hash)?.view ?? 'explore'
}
function preference<T extends string>(name: string, values: readonly T[], fallback: T) {
  try {
    const saved = localStorage.getItem(name)
    return values.includes(saved as T) ? saved as T : fallback
  } catch { return fallback }
}
function Hero({ onExplore, onTour }: { onExplore: () => void; onTour: () => void }) {
  return <motion.section className="hero" aria-labelledby="everest-title" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .46 }}>
    <p className="hero-region"><span aria-hidden="true" /> Himalája <i /> Nepál / Tibet</p>
    <h1 id="everest-title"><span>EVEREST</span><em>A világ tetején</em></h1>
    <p className="hero-copy">Fedezd fel a Föld legmagasabb hegyét a Khumbu-gleccsertől a csúcsig.</p>
    <div className="hero-actions">
      <button type="button" className="primary-button" onClick={onExplore}><Box size={19} /> Felfedezés 3D-ben</button>
      <button type="button" className="secondary-button" onClick={onTour}><Play size={16} fill="currentColor" /> Tárlatvezetés</button>
    </div>
    <Coordinates />
  </motion.section>
}

type Modal = 'locations' | 'credits' | 'quiz' | null
type Status = 'waiting' | 'terrain' | 'model' | 'webgl'

function App() {
  const [view, setView] = useState<View>(currentView)
  const [terrain, setTerrain] = useState(false)
  const [selected, setSelected] = useState('summit')
  const [focus, setFocus] = useState<string | null>(null)
  const [focusSerial, updateFocus] = useState(0)
  const [detail, setDetail] = useState(false)
  const [altitude, setAltitude] = useState<number>(SUMMIT)
  const [weatherId, setWeather] = useState<WeatherId>('day')
  const [quality, setQuality] = useState<Quality>(() => preference('everest.atlas.quality', ['eco', 'balanced', 'high'], matchMedia('(max-width: 640px)').matches ? 'eco' : 'balanced'))
  const [routeVisible, setRouteVisible] = useState(true)
  const [peaksVisible, setPeaksVisible] = useState(true)
  const [rotating, setRotating] = useState(false)
  const [settings, setSettings] = useState(false)
  const [modal, setModal] = useState<Modal>(null)
  const [command, setCommand] = useState<CameraCommand | null>(null)
  const [comparison, setComparison] = useState<ComparisonId>('everest')
  const [comparisonFocus, setComparisonFocus] = useState<ComparisonId | null>(null)
  const [status, setStatus] = useState<Status>('waiting')
  const [fullscreen, setFullscreen] = useState(false)
  const [fullFallback, setFullFallback] = useState(false)
  const [tour, dispatchTour] = useReducer(tourReducer, idleTour)
  const surface = useRef<HTMLDivElement>(null)
  const cameraSequence = useRef(0)
  const [hasRunTour, setHasRunTour] = useState(false)
  const audio = useAmbientAudio()
  const motionReduced = Boolean(useReducedMotion())
  const comparisonMode = view === 'compare'
  const useThree = comparisonMode || terrain
  const hasPanel = view !== 'explore' || detail
  const weather = weatherPresets.find(item => item.id === weatherId) ?? weatherPresets[1]
  const activePlace = placeById[selected]

  function switchView(next: View, history: 'push' | 'reset' = 'push') {
    setView(next)
    setSettings(false)
    setDetail(false)
    setCommand(null)
    setRotating(false)
    setComparisonFocus(null)
    dispatchTour({ type: 'close' })
    const hash = navigation.find(item => item.view === next)?.hash ?? ''
    if (window.location.hash !== hash) {
      const url = window.location.pathname + window.location.search + hash
      window.history[history === 'push' ? 'pushState' : 'replaceState'](null, '', url)
    }
  }
  useEffect(() => {
    const navigate = () => {
      setView(currentView())
      setDetail(false)
      setSettings(false)
      setRotating(false)
      setComparisonFocus(null)
      setCommand(null)
      dispatchTour({ type: 'close' })
    }
    window.addEventListener('popstate', navigate)
    window.addEventListener('hashchange', navigate)
    return () => {
      window.removeEventListener('popstate', navigate)
      window.removeEventListener('hashchange', navigate)
    }
  }, [])
  useEffect(() => {
    try { localStorage.setItem('everest.atlas.quality', quality) } catch { /* Optional preference. */ }
  }, [quality])
  useEffect(() => {
    const sync = () => setFullscreen(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', sync)
    return () => document.removeEventListener('fullscreenchange', sync)
  }, [])
  useEffect(() => {
    const escape = (event: globalThis.KeyboardEvent) => {
      if (event.key !== 'Escape' || modal) return
      if (settings) setSettings(false)
      else if (fullFallback) setFullFallback(false)
      else if (detail) setDetail(false)
    }
    window.addEventListener('keydown', escape)
    return () => window.removeEventListener('keydown', escape)
  }, [settings, fullFallback, detail, modal])

  const focusPlace = useCallback((id: string) => {
    setSelected(id)
    setAltitude(placeById[id].altitude)
    setFocus(id)
    updateFocus(value => value + 1)
    setDetail(true)
    setTerrain(true)
    setCommand(null)
    setRotating(false)
  }, [])
  const openPlace = useCallback((id: string) => {
    dispatchTour({ type: 'close' })
    focusPlace(id)
  }, [focusPlace])
  function chooseLocationFromIndex(id: string) {
    setModal(null)
    if (view !== 'explore') switchView('explore')
    openPlace(id)
  }
  const onSceneSelect = useCallback((id: string) => {
    if (view === 'air') {
      setSelected(id)
      setAltitude(placeById[id].altitude)
      setFocus(id)
      updateFocus(value => value + 1)
    } else if (view === 'explore') openPlace(id)
    else {
      setFocus(id)
      updateFocus(value => value + 1)
    }
  }, [openPlace, view])

  function startTour() {
    if (view !== 'explore') switchView('explore')
    setSettings(false)
    setHasRunTour(true)
    setModal(null)
    setTerrain(true)
    dispatchTour({ type: 'start' })
    if (tour.chapter === 0) focusPlace(chapters[0].place)
  }
  useEffect(() => {
    if (tour.chapter < 0) return
    focusPlace(chapters[tour.chapter].place)
  }, [tour.chapter, focusPlace])
  useEffect(() => {
    if (!tour.playing) return
    let last = performance.now()
    const timer = window.setInterval(() => {
      const now = performance.now()
      dispatchTour({ type: 'tick', delta: Math.min(600, now - last) })
      last = now
    }, 105)
    const onVisibility = () => { if (document.visibilityState === 'hidden') dispatchTour({ type: 'pause' }) }
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.clearInterval(timer)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [tour.playing])
  useEffect(() => {
    if (!tour.finished) return
    setDetail(false)
    setModal('quiz')
  }, [tour.finished])

  function changeTerrain(next: boolean) {
    setTerrain(next)
    setRotating(false)
    setCommand(null)
    if (!next) {
      dispatchTour({ type: 'close' })
      setDetail(false)
      setStatus('waiting')
    }
    setFocus(null)
    updateFocus(value => value + 1)
  }
  function reset() {
    switchView('explore', 'reset')
    changeTerrain(false)
    setSelected('summit')
    setAltitude(SUMMIT)
    setModal(null)
  }
  function moveCamera(action: CameraAction) {
    if (action === 'overview') {
      setFocus(null)
      setComparisonFocus(null)
      setCommand(null)
      updateFocus(value => value + 1)
      return
    }
    setCommand({ serial: ++cameraSequence.current, action })
  }
  function keyboardCamera(event: KeyboardEvent<HTMLDivElement>) {
    if (!useThree || event.currentTarget !== event.target) return
    const directions: Record<string, CameraAction> = { '+': 'zoomIn', '=': 'zoomIn', '-': 'zoomOut', ArrowLeft: 'turnLeft', ArrowRight: 'turnRight', '0': 'overview' }
    const action = directions[event.key]
    if (!action) return
    event.preventDefault()
    moveCamera(action)
  }
  async function toggleFullscreen() {
    if (document.fullscreenElement) { await document.exitFullscreen().catch(() => {}); return }
    if (fullFallback) { setFullFallback(false); return }
    try {
      if (!surface.current?.requestFullscreen) { setFullFallback(true); return }
      await surface.current.requestFullscreen()
    } catch { setFullFallback(true) }
  }
  function openDialog(value: Modal) {
    setSettings(false)
    if (value) dispatchTour({ type: 'pause' })
    setModal(value)
  }
  function closeTour() {
    dispatchTour({ type: 'close' })
    setDetail(false)
  }
  const label3d = comparisonMode ? 'Magasságok 3D-ben' : status === 'model' ? 'Szemléltető terep' : status === 'webgl' ? 'WebGL nélkül' : 'Valós domborzat'
  const showHero = view === 'explore' && !terrain && !detail

  return <MotionConfig reducedMotion="user">
    <div className={'atlas-app' + (fullFallback ? ' fullscreen-fallback' : '')} ref={surface}>
      <a className="skip-link" href="#terep" onClick={event => {
        event.preventDefault()
        document.getElementById('terep')?.focus()
      }}>Ugrás a terepre</a>
      <header className="topbar">
        <button type="button" className="brand" onClick={reset} aria-label="Everest nyitóoldal">
          <span className="brand-sign"><MountainSnow size={24} strokeWidth={1.7} /></span>
          <span className="brand-text"><strong>EVEREST</strong><small>Himalája-atlasz</small></span>
        </button>
        <nav className="navigation" aria-label="Az atlasz nézetei">
          {navigation.map(item => <button type="button" key={item.view} aria-label={item.label} title={item.label}
            aria-current={view === item.view ? 'page' : undefined} className={view === item.view ? 'active' : ''} onClick={() => switchView(item.view)}>
            <item.icon size={17} /><span>{item.label}</span>
          </button>)}
        </nav>
        <div className="header-tools">
          <IconButton label={audio.enabled ? 'Hang elnémítása' : 'Hang bekapcsolása'} aria-pressed={audio.enabled} onClick={audio.toggle}>
            {audio.enabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </IconButton>
          <IconButton label={fullscreen || fullFallback ? 'Kilépés teljes képernyőből' : 'Teljes képernyő'} aria-pressed={fullscreen || fullFallback} onClick={() => { void toggleFullscreen() }}>
            {fullscreen || fullFallback ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
          </IconButton>
          <IconButton label="Beállítások" aria-expanded={settings} aria-controls={settings ? 'atlas-settings' : undefined} onClick={() => setSettings(value => !value)}>
            <Settings2 size={18} />
          </IconButton>
        </div>
      </header>
      {settings && <section className="settings-popover glass" id="atlas-settings" aria-labelledby="settings-title">
        <h2 id="settings-title">Beállítások</h2>
        <label className="quality-label" htmlFor="quality">Grafikai minőség</label>
        <select id="quality" value={quality} onChange={event => setQuality(event.currentTarget.value as Quality)}>
          {Object.entries(qualityNames).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
        </select>
        <div className="settings-checks">
          <label><input type="checkbox" checked={routeVisible} onChange={event => setRouteVisible(event.currentTarget.checked)} /> Déli útvonal jelölése</label>
          <label><input type="checkbox" checked={peaksVisible} onChange={event => setPeaksVisible(event.currentTarget.checked)} /> Környező csúcsok neve</label>
          <label><input type="checkbox" checked={audio.wind} onChange={event => audio.setWind(event.currentTarget.checked)} /> Szélhang</label>
          <label><input type="checkbox" checked={audio.music} onChange={event => audio.setMusic(event.currentTarget.checked)} /> Háttérzene</label>
        </div>
        {audio.error && <p className="audio-error" role="status">Ebben a böngészőben a hang nem indult el.</p>}
        <button className="text-button" type="button" onClick={() => startTour()}><Route size={16} /> Tárlatvezetés indítása</button>
        <button className="text-button" type="button" onClick={() => { dispatchTour({ type: 'close' }); openDialog('quiz') }}><BookOpen size={16} /> Everest-kvíz</button>
        <button className="text-button" type="button" onClick={() => openDialog('credits')}><Download size={16} /> Források és letöltés</button>
      </section>}
      <main className={'mission view-' + view + (useThree ? ' on-terrain' : ' on-poster') + (hasPanel ? ' has-panel' : '') + (tour.chapter !== -1 ? ' in-tour' : '')}>
        <div id="terep" className="stage" role="region" aria-label={useThree ? 'Forgatható 3D terep' : 'Everest-panoráma'} tabIndex={0} onKeyDown={keyboardCamera}>
          <div className="stage-visual">
            <Panorama weather={weatherId} markers={false} route={false} active={selected} onSelect={openPlace} />
            {useThree && <div className="scene-layer">
              <Suspense fallback={<LoadingMountain />}>
                <TerrainScene mode={comparisonMode ? 'compare' : 'terrain'} active={selected} focus={focus} focusSerial={focusSerial}
                  comparison={comparison} comparisonFocus={comparisonFocus} weather={weather} quality={quality} showPanel={hasPanel}
                  showRoute={routeVisible} showPeaks={peaksVisible} rotating={rotating} tourPlaying={tour.playing}
                  reduced={motionReduced} altitude={view === 'air' ? altitude : undefined} command={command}
                  onStatus={setStatus} onSelect={onSceneSelect} onCompare={setComparison} />
              </Suspense>
            </div>}
          </div>
          <div className="vignette" aria-hidden="true" />
          {!useThree && view === 'explore' && <div className="poster-hud">
            <Panorama weather={weatherId} markers route={routeVisible} active={selected} onSelect={openPlace} />
          </div>}
          {showHero && <Hero onExplore={() => changeTerrain(true)} onTour={startTour} />}
          {useThree && !hasPanel && <SceneGuide onIndex={() => openDialog('locations')} />}
          {useThree && <div className="scene-indicator"><span aria-hidden="true" /> {label3d}</div>}
          {showHero && <MiniMap active={selected} onOpen={() => openDialog('locations')} />}
          {view === 'explore' && terrain && !detail && <button type="button" className="orbit-tour-button glass" onClick={startTour}><Play size={15} fill="currentColor" /> Tárlatvezetés</button>}
          <TourBar tour={tour} onToggle={() => dispatchTour({ type: 'toggle' })}
            onMove={delta => dispatchTour({ type: 'seek', index: tour.chapter + delta })}
            onSeek={index => dispatchTour({ type: 'seek', index })} onClose={closeTour} />
          <div className="stage-toolbar">
            {!comparisonMode && <WeatherDock value={weatherId} onChange={setWeather} />}
            <CameraDock three={terrain} comparable={comparisonMode} rotating={rotating} onRotate={() => setRotating(value => !value)}
              onCommand={moveCamera} onView={changeTerrain} />
          </div>
        </div>
        <AnimatePresence initial={false}>
          {view === 'explore' && detail && <PlacePanel key="place" place={activePlace} onSelect={openPlace} onClose={() => setDetail(false)} />}
          {view === 'air' && <AirPanel key="air" altitude={altitude} onChange={setAltitude} />}
          {view === 'museum' && <MuseumPanel key="museum" onSources={() => openDialog('credits')} />}
          {view === 'compare' && <ComparePanel key="compare" selected={comparison} onSelect={setComparison}
            onFocus={() => { setComparisonFocus(comparison); updateFocus(value => value + 1) }} />}
        </AnimatePresence>
        {(view === 'explore' || view === 'air') && <Profile selected={selected} altitude={altitude} inAir={view === 'air'}
          onSelect={id => view === 'air' ? onSceneSelect(id) : openPlace(id)} onIndex={() => openDialog('locations')} />}
      </main>
      <footer className="footer">
        <div><span className="footer-mark" aria-hidden="true" /><span>{useThree ? label3d : 'Illusztrált panoráma'}</span><i /><span>{comparisonMode ? 'Közös magassági skála' : 'Déli útvonal'}</span></div>
        <button type="button" onClick={() => openDialog('credits')}><Info size={14} /> Források és letöltés</button>
        <div className="footer-right">{useThree ? 'Húzás · forgatás · görgetés · nagyítás' : '27°59′17″ É · 86°55′30″ K'}</div>
      </footer>
      {modal && <AtlasDialog key={modal} title={modal === 'locations' ? 'Helyszínjegyzék' : modal === 'quiz' ? 'Everest-kvíz' : 'Források és letöltés'}
        wide={modal === 'locations'} onClose={() => setModal(null)}>
        {modal === 'locations' && <LocationsDialog onSelect={chooseLocationFromIndex} />}
        {modal === 'credits' && <CreditsDialog />}
        {modal === 'quiz' && <QuizDialog onClose={() => setModal(null)} />}
      </AtlasDialog>}
      {hasRunTour && tour.finished && !modal && <button className="resume-quiz glass" type="button" onClick={() => openDialog('quiz')}><ChevronsUp size={17} /> A kvíz megnyitása</button>}
    </div>
  </MotionConfig>
}

createRoot(document.getElementById('root')!).render(<App />)
