import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, Line, Stars } from '@react-three/drei'
import * as THREE from 'three'
import { neighboringPeaks, placeById, places, route, type Quality, type Weather } from './core'
import { elevationAt, innerRect, outerRect, toHeight, toWorld, type TerrainData } from './terrain'

const terrainFunction = `
varying vec3 vAtlasPosition;
varying vec3 vAtlasNormal;
float atlasHash(vec3 q) {
  q = fract(q * 0.3183099 + vec3(.11,.17,.12));
  q *= 19.0;
  return fract(q.x * q.y * q.z * (q.x + q.y + q.z));
}
float atlasNoise(vec3 p) {
  vec3 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(mix(atlasHash(i),atlasHash(i+vec3(1,0,0)),f.x),mix(atlasHash(i+vec3(0,1,0)),atlasHash(i+vec3(1,1,0)),f.x),f.y),
    mix(mix(atlasHash(i+vec3(0,0,1)),atlasHash(i+vec3(1,0,1)),f.x),mix(atlasHash(i+vec3(0,1,1)),atlasHash(i+vec3(1,1,1)),f.x),f.y), f.z);
}
`

function createLandMaterial() {
  const material = new THREE.MeshStandardMaterial({ roughness: 0.93 })
  material.onBeforeCompile = shader => {
    shader.vertexShader = shader.vertexShader.replace('#include <common>', `#include <common>
      varying vec3 vAtlasPosition;
      varying vec3 vAtlasNormal;`).replace('#include <begin_vertex>', `#include <begin_vertex>
      vAtlasPosition = position;
      vAtlasNormal = normal;`)
    shader.fragmentShader = shader.fragmentShader.replace('#include <common>', '#include <common>\n' + terrainFunction)
      .replace('#include <color_fragment>', `#include <color_fragment>
        vec3 p = vAtlasPosition;
        float flatness = normalize(vAtlasNormal).y;
        float large = atlasNoise(vec3(p.x * 1.8, p.y * 2.9, p.z * 1.7));
        float fine = atlasNoise(vec3(p.x * 13.0, p.y * 24.0, p.z * 15.0));
        float strata = sin(p.y * 38.0 + p.x * 13.6 - p.z * 4.6 + fine * 8.0) * .045;
        float micro = atlasNoise(p * 81.0);
        float snowline = smoothstep(1.01,2.78,p.y + (large-.5) * 1.0 + fine * .23);
        float steepRock = smoothstep(.47,.80,flatness + (large-.54)*.35 + fine*.13);
        float iceMask = smoothstep(.76,.96,flatness) * smoothstep(.58,1.55,p.y) * (1.0-smoothstep(2.65,4.05,p.y));
        float crevasse = pow(abs(sin(p.z*79.0 + p.x*73.0 + large*24.0 + fine*2.0)),18.0);
        vec3 rock = mix(vec3(.048,.063,.079),vec3(.205,.208,.208),large*.74+fine*.22+strata);
        vec3 ice = mix(vec3(.16,.32,.43),vec3(.56,.73,.80),fine*.73 + .13);
        ice *= 1.0 - .27 * crevasse;
        vec3 snow = mix(vec3(.59,.71,.80),vec3(.88,.93,.98),.28 + fine*.52);
        snow *= .88 + .17 * micro;
        float cover = clamp(snowline*steepRock + smoothstep(4.16,5.35,p.y)*.31,0.0,1.0);
        diffuseColor.rgb *= mix(mix(rock, ice, iceMask*.91),snow,cover*(1.0-iceMask*.35));`)
  }
  material.customProgramCacheKey = () => 'atlas-rock-ice-snow'
  return material
}

function makePatch(rect: typeof innerRect, sx: number, sz: number, data: TerrainData | null) {
  const geometry = new THREE.PlaneGeometry(rect.maxX - rect.minX, rect.maxZ - rect.minZ, sx, sz)
  geometry.rotateX(-Math.PI / 2)
  geometry.translate((rect.minX + rect.maxX) / 2, 0, (rect.minZ + rect.maxZ) / 2)
  const positions = geometry.attributes.position
  for (let i = 0; i < positions.count; i++) {
    positions.setY(i, toHeight(elevationAt(positions.getX(i), positions.getZ(i), data)))
  }
  geometry.computeVertexNormals()
  return geometry
}

export function TerrainMesh({ data, quality }: { data: TerrainData | null; quality: Quality }) {
  const material = useMemo(createLandMaterial, [])
  const geometries = useMemo(() => {
    const n = quality === 'high' ? 440 : quality === 'balanced' ? 240 : 124
    const near = makePatch(innerRect, n, Math.round(n * 0.74), data)
    const x = [outerRect.minX, innerRect.minX, innerRect.maxX, outerRect.maxX]
    const z = [outerRect.minZ, innerRect.minZ, innerRect.maxZ, outerRect.maxZ]
    const background: THREE.PlaneGeometry[] = []
    for (let yi = 0; yi < 3; yi++) for (let xi = 0; xi < 3; xi++) {
      if (xi === 1 && yi === 1) continue
      background.push(makePatch({ minX: x[xi], maxX: x[xi + 1], minZ: z[yi], maxZ: z[yi + 1] },
        Math.ceil((x[xi + 1] - x[xi]) * 2.2), Math.ceil((z[yi + 1] - z[yi]) * 2.15), data))
    }
    return [near, ...background]
  }, [data, quality])

  useEffect(() => () => geometries.forEach(geometry => geometry.dispose()), [geometries])
  useEffect(() => () => material.dispose(), [material])

  return <group>
    {geometries.map((geometry, i) => (
      <mesh key={i} geometry={geometry} material={material} castShadow={i === 0 && quality !== 'eco'} receiveShadow />
    ))}
  </group>
}

const SKY_VERTEX = `varying vec3 worldDirection;
void main(){ worldDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`
const SKY_FRAGMENT = `
varying vec3 worldDirection;
uniform vec3 skyTop;
uniform vec3 horizon;
uniform vec3 sunColor;
uniform vec3 sunDirection;
uniform float sunAmount;
void main(){
  vec3 d=normalize(worldDirection);
  float gradient=pow(max(d.y+.035,0.0),.43);
  vec3 color=mix(horizon,skyTop,clamp(gradient*1.38,0.0,1.0));
  float ray=max(dot(d,sunDirection),0.0);
  color+=sunColor*sunAmount*(pow(ray,18.0)*.14+pow(ray,220.0)*.39);
  gl_FragColor=vec4(color,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`
function Sky({ weather }: { weather: Weather }) {
  const uniforms = useMemo(() => ({
    skyTop: { value: new THREE.Color() },
    horizon: { value: new THREE.Color() },
    sunColor: { value: new THREE.Color() },
    sunDirection: { value: new THREE.Vector3() },
    sunAmount: { value: 0 },
  }), [])
  useFrame((_, delta) => {
    const weight = 1 - Math.exp(-delta * 2.2)
    uniforms.skyTop.value.lerp(new THREE.Color(weather.sky), weight)
    uniforms.horizon.value.lerp(new THREE.Color(weather.horizon), weight)
    uniforms.sunColor.value.lerp(new THREE.Color(weather.sun), weight)
    uniforms.sunDirection.value.lerp(new THREE.Vector3(...weather.sunPosition).normalize(), weight)
    uniforms.sunAmount.value = THREE.MathUtils.lerp(uniforms.sunAmount.value, weather.id === 'fog' || weather.id === 'storm' || weather.id === 'night' ? 0.1 : 1, weight)
  })
  return <mesh renderOrder={-10}>
    <sphereGeometry args={[105, 35, 20]} />
    <shaderMaterial uniforms={uniforms} vertexShader={SKY_VERTEX} fragmentShader={SKY_FRAGMENT} side={THREE.BackSide} depthWrite={false} />
  </mesh>
}

function random(seed: number) {
  let state = seed
  return () => {
    state = (1664525 * state + 1013904223) >>> 0
    return state / 0x100000000
  }
}
function cloudTexture() {
  const source = document.createElement('canvas')
  source.width = 512
  source.height = 192
  const ctx = source.getContext('2d')
  if (!ctx) return new THREE.Texture()
  const next = random(7821)
  for (let i = 0; i < 52; i++) {
    const x = 66 + next() * 377
    const y = 35 + Math.sin(x * 0.013) * 12 + next() * 92
    const radius = 12 + next() * 40
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
    gradient.addColorStop(0, 'rgba(255,255,255,.22)')
    gradient.addColorStop(0.35, 'rgba(238,243,251,.12)')
    gradient.addColorStop(1, 'rgba(214,227,244,0)')
    ctx.fillStyle = gradient
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2)
  }
  const map = new THREE.CanvasTexture(source)
  map.colorSpace = THREE.SRGBColorSpace
  return map
}
function Clouds({ weather, quality, still }: { weather: Weather; quality: Quality; still: boolean }) {
  const map = useMemo(cloudTexture, [])
  const group = useRef<THREE.Group>(null)
  const cloudPositions = useMemo(() => {
    const next = random(346)
    return Array.from({ length: quality === 'eco' ? 10 : 21 }, () => ({
      x: (next() - 0.5) * 88, z: (next() - 0.53) * 71,
      y: next() * 3 + 0.85, width: next() * 9 + 12, height: next() * 2 + 0.9,
    }))
  }, [quality])
  useEffect(() => () => map.dispose(), [map])
  useFrame(({ clock }) => {
    if (!group.current || still) return
    const amp = weather.id === 'storm' ? 4.2 : 2.2
    group.current.position.x = Math.sin(clock.elapsedTime * 0.115) * amp
    group.current.position.z = Math.sin(clock.elapsedTime * 0.056) * 1.1
  })
  return <group ref={group}>
    {cloudPositions.map(({ x, y, z, width, height }, i) => (
      <sprite key={i} position={[x, y, z]} scale={[width, height, 1]}>
        <spriteMaterial map={map} transparent depthWrite={false}
          color={weather.id === 'night' ? '#3e5e89' : weather.id === 'dawn' || weather.id === 'dusk' ? '#e4ad9c' : '#cddfed'}
          opacity={weather.id === 'fog' || weather.id === 'storm' ? 0.62 : 0.44} />
      </sprite>
    ))}
  </group>
}

function Snow({ quality, still }: { quality: Quality; still: boolean }) {
  const group = useRef<THREE.Points>(null)
  const particles = useMemo(() => {
    const next = random(621)
    const count = quality === 'high' ? 1900 : quality === 'balanced' ? 1060 : 430
    return Float32Array.from({ length: count * 3 }, (_, i) => (next() - .5) * (i % 3 === 1 ? 14 : 28))
  }, [quality])
  useFrame(({ camera }, delta) => {
    if (!group.current) return
    group.current.position.copy(camera.position)
    if (still) return
    const attr = group.current.geometry.attributes.position
    for (let i = 0; i < attr.count; i++) {
      const x = attr.getX(i) + delta * 3.2
      const y = attr.getY(i) - delta * 1.9
      attr.setX(i, x > 14 ? x - 28 : x)
      attr.setY(i, y < -7 ? y + 14 : y)
    }
    attr.needsUpdate = true
  })
  return <points ref={group} frustumCulled={false}>
    <bufferGeometry><bufferAttribute attach="attributes-position" args={[particles, 3]} /></bufferGeometry>
    <pointsMaterial color="#e5f5ff" size={0.045} transparent opacity={0.75} depthWrite={false} />
  </points>
}

export function MountainWeather({ weather, quality, reduced }: { weather: Weather; quality: Quality; reduced: boolean }) {
  const sunlight = useRef<THREE.DirectionalLight>(null)
  const hemisphere = useRef<THREE.HemisphereLight>(null)
  const fog = useRef<THREE.FogExp2>(null)
  const lightColor = useMemo(() => new THREE.Color(weather.sun), [weather.sun])
  const fogColor = useMemo(() => new THREE.Color(weather.fog), [weather.fog])
  const sunPosition = useMemo(() => new THREE.Vector3(...weather.sunPosition), [weather.sunPosition])
  useFrame((_, delta) => {
    const f = 1 - Math.exp(-Math.min(delta, 0.1) * 2.2)
    if (fog.current) {
      fog.current.color.lerp(fogColor, f)
      fog.current.density = THREE.MathUtils.lerp(fog.current.density, weather.haze, f)
    }
    if (sunlight.current) {
      const light = sunlight.current
      light.position.lerp(sunPosition, f)
      light.color.lerp(lightColor, f)
      light.intensity = THREE.MathUtils.lerp(light.intensity, weather.intensity, f)
    }
    if (hemisphere.current) hemisphere.current.intensity = THREE.MathUtils.lerp(hemisphere.current.intensity, weather.ambient, f)
  })

  return <>
    <Sky weather={weather} />
    <fogExp2 ref={fog} attach="fog" args={['#8aaed0', 0.010]} />
    <hemisphereLight ref={hemisphere} args={['#d9ecff', '#303e53', 1.36]} />
    <directionalLight ref={sunlight} position={[-33, 41, 27]} color="#eff8ff" intensity={3.1} castShadow={quality !== 'eco'}
      shadow-mapSize={[quality === 'high' ? 2048 : 1024, quality === 'high' ? 2048 : 1024]}
      shadow-camera-left={-15} shadow-camera-right={15} shadow-camera-top={13} shadow-camera-bottom={-13}
      shadow-camera-far={98} shadow-normalBias={0.035} shadow-bias={-0.00045} />
    {weather.id === 'night' && <Stars radius={90} depth={8} count={1550} factor={3} saturation={0.12} fade speed={reduced ? 0 : 0.22} />}
    <Clouds weather={weather} quality={quality} still={reduced} />
    {weather.flakes > 0 && <Snow quality={quality} still={reduced} />}
  </>
}

export function usePlacePositions(data: TerrainData | null) {
  return useMemo(() => Object.fromEntries(places.map(place => {
    const [x, z] = toWorld(place.geo)
    return [place.id, new THREE.Vector3(x, toHeight(elevationAt(x, z, data)), z)]
  })) as Record<string, THREE.Vector3>, [data])
}
function Tent({ canopy, position, rotation, index }: { canopy: string; position: [number, number, number]; rotation: number; index: number }) {
  if (index % 3 === 0) return <group position={position} rotation={[0, rotation, 0]}>
    <mesh position={[0, 0.014, 0]} scale={[1.08, 0.67, 1.28]}>
      <sphereGeometry args={[0.034, 9, 6, 0, 2 * Math.PI, 0, Math.PI * 0.64]} /><meshStandardMaterial color={canopy} roughness={0.7} />
    </mesh>
    <mesh position={[0, 0.015, 0.042]} scale={[1, 1.04, 0.27]}><sphereGeometry args={[0.016, 7, 5]} /><meshStandardMaterial color="#302a3a" /></mesh>
  </group>
  return <group position={position} rotation={[0, rotation, 0]}>
    <mesh position={[0, 0.02, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.035, 0.035, 0.071, 3]} /><meshStandardMaterial color={canopy} flatShading />
    </mesh>
    <mesh position={[0, 0.02, 0.036]}><circleGeometry args={[0.011, 3]} /><meshStandardMaterial color="#293442" side={THREE.DoubleSide} /></mesh>
    <mesh position={[0, 0.004, 0]}><boxGeometry args={[0.061, 0.007, 0.075]} /><meshStandardMaterial color="#293744" /></mesh>
  </group>
}
function Camps({ positions, data }: { positions: Record<string, THREE.Vector3>; data: TerrainData | null }) {
  const colors = ['#f2ac42', '#f96549', '#61d9dc', '#e5ce43', '#2d81c3']
  const tents = useMemo(() => places.filter(place => place.kind === 'camp').flatMap(place => {
    const { x, z } = positions[place.id]
    const next = random(Math.round(place.altitude))
    const count = place.id === 'base' ? 19 : place.id === 'col' ? 8 : 6
    return Array.from({ length: count }, (_, i) => {
      const r = Math.sqrt(i) * 0.088
      const dx = Math.sin(i * 2.4) * r, dz = Math.cos(i * 2.4) * r
      return { key: place.id + i, index: i, color: colors[i % colors.length],
        position: [x + dx, toHeight(elevationAt(x + dx, z + dz, data)) + 0.01, z + dz] as [number, number, number],
        rotation: next() * Math.PI * 2,
      }
    })
  }), [positions, data])
  return <group>{tents.map(tent => <Tent key={tent.key} position={tent.position} canopy={tent.color} rotation={tent.rotation} index={tent.index} />)}</group>
}
function Memorial({ position, still }: { position: THREE.Vector3; still: boolean }) {
  const flags = useRef<THREE.Group>(null)
  const colors = ['#1898e3', '#ebf2ed', '#e54654', '#4ca972', '#e6bf4d']
  useFrame(({ clock }) => {
    if (still) return
    flags.current?.children.forEach((flag, index) => {
      flag.rotation.z = Math.sin(clock.elapsedTime * 3.5 + index * 0.47) * 0.23
      flag.rotation.y = Math.sin(clock.elapsedTime * 5 + index * 0.86) * 0.33
    })
  })
  return <group position={position}>
    <mesh position={[0, 0.026, 0]}><cylinderGeometry args={[0.045, 0.081, 0.052, 6]} /><meshStandardMaterial color="#667282" flatShading /></mesh>
    <mesh position={[0, 0.066, 0]}><cylinderGeometry args={[0.024, 0.05, 0.031, 6]} /><meshStandardMaterial color="#869099" flatShading /></mesh>
    {[-0.24, 0.24].map(x => <mesh key={x} position={[x, 0.12, 0]}><cylinderGeometry args={[0.004, 0.006, 0.24, 6]} /><meshStandardMaterial color="#8b7362" /></mesh>)}
    <Line points={[[-0.24, .22, 0], [-0.12, .197, 0], [0, .188, 0], [0.12, .197, 0], [0.24, .22, 0]]} color="#bab5ab" lineWidth={1} />
    <group ref={flags}>
      {Array.from({ length: 10 }, (_, index) => {
        const x = (index - 4.5) * .0415
        return <mesh key={index} position={[x, 0.166 + x * x * .55, 0]}>
          <planeGeometry args={[0.034, 0.044]} /><meshStandardMaterial color={colors[index % colors.length]} side={THREE.DoubleSide} roughness={0.9} />
        </mesh>
      })}
    </group>
  </group>
}

export function TerrainFeatures({ data, positions, active, showRoute, showPeaks, altitude, reduced, onSelect }: {
  data: TerrainData | null; positions: Record<string, THREE.Vector3>; active: string; showRoute: boolean;
  showPeaks: boolean; altitude?: number; reduced: boolean; onSelect: (id: string) => void
}) {
  const routePoints = useMemo(() => route.flatMap((id, i) => {
    if (i === route.length - 1) return [positions[id].clone().add(new THREE.Vector3(0, 0.055, 0))]
    const current = positions[id]
    const next = positions[route[i + 1]]
    const segments = Math.max(4, Math.ceil(current.distanceTo(next) * 11))
    return Array.from({ length: segments }, (_, j) => {
      const point = current.clone().lerp(next, j / segments)
      point.y = toHeight(elevationAt(point.x, point.z, data)) + 0.065
      return point
    })
  }), [data, positions])
  return <>
    {showRoute && <Line points={routePoints} color="#63e8ff" lineWidth={1.55} transparent opacity={0.78} dashed dashSize={0.108} gapSize={0.066} />}
    {altitude !== undefined && altitude > 4000 && <Line
      points={Array.from({ length: 65 }, (_, index) => {
        const angle = index / 64 * 2 * Math.PI
        return [Math.cos(angle) * 6, toHeight(altitude), Math.sin(angle) * 6] as [number, number, number]
      })} color={altitude >= 8000 ? '#f5ba8d' : '#67f3ff'} dashed dashSize={.20} gapSize={.11} transparent opacity={.75} lineWidth={1.4} />}
    <Camps positions={positions} data={data} />
    <Memorial position={positions.memorial} still={reduced} />
    {places.map(place => {
      const point = positions[place.id]
      return <Html key={place.id} center position={[point.x, point.y + (place.id === 'summit' ? 0.13 : 0.095), point.z]}
        zIndexRange={active === place.id ? [14, 13] : [11, 2]}>
        <button className={'world-pin world-pin--' + place.kind + (active === place.id ? ' is-selected' : '')}
          type="button" title={place.name} aria-label={place.name} onClick={() => onSelect(place.id)}>
          <span aria-hidden="true" /><b>{place.short}</b>
        </button>
      </Html>
    })}
    {showPeaks && neighboringPeaks.map(peak => {
      const [x, z] = toWorld(peak.geo)
      return <Html key={peak.name} center position={[x, toHeight(elevationAt(x, z, data)) + .17, z]} zIndexRange={[1, 0]} style={{ pointerEvents: 'none' }}>
        <span className="peak-tag">{peak.name} · {peak.altitude} m</span>
      </Html>
    })}
  </>
}
