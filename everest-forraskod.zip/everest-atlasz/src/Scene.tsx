import { Component, memo, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import type { OrbitControls as Controls } from 'three-stdlib'
import * as THREE from 'three'
import { placeById, type ComparisonId, type Quality, type Weather } from './core'
import { elevationAt, loadTerrain, toHeight, type TerrainData } from './terrain'
import { MountainWeather, TerrainFeatures, TerrainMesh, usePlacePositions } from './mountain'
import { ComparisonWorld, comparisonPosition } from './comparison'
import { LoadingMountain } from './LoadingMountain'

export type CameraAction = 'zoomIn' | 'zoomOut' | 'turnLeft' | 'turnRight' | 'overview'
export type CameraCommand = { serial: number; action: CameraAction }
type CameraPose = { position: THREE.Vector3; target: THREE.Vector3 }

function Rig({ flight, command, rotate, tourDrift, reduced, comparison, panel, comparisonFocus }: {
  flight: CameraPose; command: CameraCommand | null; rotate: boolean; tourDrift: boolean;
  reduced: boolean; comparison: boolean; panel: boolean; comparisonFocus: boolean
}) {
  const controls = useRef<Controls>(null)
  const initial = useRef(flight)
  const path = useRef<{ from: CameraPose; time: number; duration: number } | null>(null)
  const lastCommand = useRef<number | null>(null)
  const camera = useThree(state => state.camera) as THREE.PerspectiveCamera
  const size = useThree(state => state.size)

  useEffect(() => {
    if (size.width >= 800) {
      const offset = Math.round(size.width * (comparison ? .165 : panel ? .093 : -.035))
      camera.setViewOffset(size.width, size.height, -offset, 0, size.width, size.height)
    } else camera.clearViewOffset()
  }, [camera, comparison, panel, size.height, size.width])

  useEffect(() => {
    const control = controls.current
    if (!control) return
    if (reduced) {
      camera.position.copy(flight.position)
      control.target.copy(flight.target)
      control.update()
      path.current = null
      return
    }
    path.current = {
      from: { position: camera.position.clone(), target: control.target.clone() },
      time: 0,
      duration: Math.min(2.3, 1.05 + camera.position.distanceTo(flight.position) * .047),
    }
  }, [camera, flight, reduced])

  useEffect(() => {
    if (!command || lastCommand.current === command.serial || command.action === 'overview') return
    const control = controls.current
    if (!control) return
    lastCommand.current = command.serial
    path.current = null
    const relative = camera.position.clone().sub(control.target)
    if (command.action === 'zoomIn' || command.action === 'zoomOut') {
      relative.setLength(THREE.MathUtils.clamp(relative.length() * (command.action === 'zoomIn' ? .77 : 1.29), .34, 70))
    } else relative.applyAxisAngle(THREE.Object3D.DEFAULT_UP, command.action === 'turnLeft' ? -.25 : .25)
    camera.position.copy(control.target).add(relative)
    control.update()
  }, [camera, command])

  useFrame((_, delta) => {
    const control = controls.current
    if (!control) return
    const transition = path.current
    if (transition) {
      transition.time = Math.min(transition.duration, transition.time + Math.min(.065, delta))
      const t = transition.time / transition.duration
      const smooth = t * t * (3 - 2 * t)
      camera.position.copy(transition.from.position).lerp(flight.position, smooth)
      camera.position.y += Math.sin(Math.PI * t) * Math.min(2.5, transition.from.position.distanceTo(flight.position) * .13)
      control.target.copy(transition.from.target).lerp(flight.target, smooth)
      if (t === 1) path.current = null
    }
    control.autoRotate = !path.current && (rotate || tourDrift && !reduced)
    control.autoRotateSpeed = rotate ? 1.1 : .49
    control.update()
  })

  return <OrbitControls ref={controls} makeDefault target={initial.current.target}
    enableDamping dampingFactor={.075} minDistance={.34} maxDistance={comparison ? 72 : 80}
    minPolarAngle={0.12} maxPolarAngle={comparison && comparisonFocus ? Math.PI * .49 : Math.PI * .477}
    onStart={() => { path.current = null }} />
}

type SceneProps = {
  mode: 'terrain' | 'compare'
  active: string
  focus: string | null
  focusSerial: number
  comparison: ComparisonId
  comparisonFocus: ComparisonId | null
  weather: Weather
  quality: Quality
  showRoute: boolean
  showPeaks: boolean
  showPanel: boolean
  reduced: boolean
  rotating: boolean
  tourPlaying: boolean
  altitude?: number
  command: CameraCommand | null
  onStatus: (status: 'terrain' | 'model' | 'webgl') => void
  onSelect: (id: string) => void
  onCompare: (id: ComparisonId) => void
}
function World({ props, data }: { props: SceneProps; data: TerrainData | null }) {
  const positions = usePlacePositions(data)
  const comparison = props.mode === 'compare'
  const aspect = useThree(state => state.size.width / Math.max(1, state.size.height))
  const { focus, focusSerial, comparisonFocus } = props
  const flight = useMemo((): CameraPose => {
    if (comparison) {
      if (comparisonFocus) {
        const { x, height } = comparisonPosition(comparisonFocus)
        const d = Math.max(.62, height * 1.45)
        return { position: new THREE.Vector3(x + d * .37, height * .66 + d * .36, d), target: new THREE.Vector3(x, height * .52, 0) }
      }
      const distance = Math.max(28, 30.8 / Math.max(.4, aspect))
      return { position: new THREE.Vector3(1.75, 12.75, distance), target: new THREE.Vector3(.25, 5.1, 0) }
    }
    if (!focus || !positions[focus]) {
      return { position: new THREE.Vector3(-13.4, 9.3, 15.7), target: new THREE.Vector3(-1.75, 2.68, .35) }
    }
    const point = positions[focus]
    const { bearing, distance, height } = placeById[focus].camera
    const angle = THREE.MathUtils.degToRad(bearing)
    const x = point.x + Math.sin(angle) * distance, z = point.z - Math.cos(angle) * distance
    const y = Math.max(point.y + height, toHeight(elevationAt(x, z, data)) + .34)
    return { position: new THREE.Vector3(x, y, z), target: point.clone().add(new THREE.Vector3(0, .1, 0)) }
  }, [aspect, comparison, comparisonFocus, data, focus, focusSerial, positions])

  return <>
    {comparison
      ? <ComparisonWorld selected={props.comparison} onSelect={props.onCompare} reduced={props.reduced} />
      : <>
        <MountainWeather weather={props.weather} quality={props.quality} reduced={props.reduced} />
        <TerrainMesh data={data} quality={props.quality} />
        <TerrainFeatures data={data} positions={positions} active={props.active} reduced={props.reduced}
          onSelect={props.onSelect} altitude={props.altitude} showPeaks={props.showPeaks} showRoute={props.showRoute} />
      </>}
    <Rig flight={flight} command={props.command} rotate={props.rotating} tourDrift={props.tourPlaying}
      reduced={props.reduced} comparison={comparison} panel={props.showPanel} comparisonFocus={Boolean(comparisonFocus)} />
  </>
}

function NoWebGL({ onStatus }: { onStatus: SceneProps['onStatus'] }) {
  useEffect(() => onStatus('webgl'), [onStatus])
  return <div className="scene-message" role="status">
    <strong>A WebGL 2 itt nem érhető el</strong>
    <span>A panoráma, a helyszínek és a magassági adatok továbbra is megnyithatók.</span>
  </div>
}
class Boundary extends Component<{ children: ReactNode; onStatus: SceneProps['onStatus'] }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() { return this.state.failed ? <NoWebGL onStatus={this.props.onStatus} /> : this.props.children }
}
function Scene(props: SceneProps) {
  const [terrain, setTerrain] = useState<TerrainData | null>(null)
  const [resolved, setResolved] = useState(false)
  const [contextLost, setContextLost] = useState(false)

  useEffect(() => {
    let active = true
    loadTerrain(import.meta.env.BASE_URL).then(data => {
      if (active) { setTerrain(data); setResolved(true); props.onStatus('terrain') }
    }, () => {
      if (active) { setResolved(true); props.onStatus('model') }
    })
    return () => { active = false }
  }, [props.onStatus])

  if (contextLost) return <NoWebGL onStatus={props.onStatus} />
  if (!resolved && props.mode === 'terrain') return <LoadingMountain />
  return <Boundary onStatus={props.onStatus}>
    <Canvas camera={{ fov: 43, near: .035, far: 215, position: props.mode === 'compare' ? [1.75, 12.75, 28] : [-13.4, 9.3, 15.7] }}
      dpr={props.quality === 'high' ? [1, 1.75] : props.quality === 'balanced' ? [1, 1.3] : 1}
      shadows={props.quality === 'eco' ? false : props.quality === 'high' ? 'soft' : 'basic'}
      gl={{ antialias: props.quality !== 'eco', powerPreference: 'high-performance' }}
      fallback={<NoWebGL onStatus={props.onStatus} />}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping
        gl.toneMappingExposure = 1.13
        gl.domElement.addEventListener('webglcontextlost', event => {
          event.preventDefault()
          setContextLost(true)
        }, { once: true })
      }}
      style={{ touchAction: 'none' }}>
      <World props={props} data={terrain} />
    </Canvas>
  </Boundary>
}
export default memo(Scene)
