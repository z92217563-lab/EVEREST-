import { useEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from 'react'
import { animate, useReducedMotion } from 'framer-motion'
import { ExternalLink } from 'lucide-react'
import { metres } from './core'
import photoData from './photos.json'

type PhotoCredit = {
  caption: string
  creator: string
  license: string
  licenseUrl: string
  source: string
}
export const photos = photoData as Record<string, PhotoCredit>
export const asset = (file: string) => import.meta.env.BASE_URL + file

export function IconButton({ children, label, className = '', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return <button type="button" className={'icon-button ' + className} aria-label={label} title={label} {...props}>{children}</button>
}

export function AnimatedNumber({ value, digits = 0 }: { value: number; digits?: number }) {
  const reduced = useReducedMotion()
  const previous = useRef(value)
  const [shown, setShown] = useState(value)
  useEffect(() => {
    if (reduced) return
    const animation = animate(previous.current, value, {
      duration: 0.34,
      ease: [0.15, 0.84, 0.24, 1],
      onUpdate: number => { previous.current = number; setShown(number) },
    })
    return () => animation.stop()
  }, [value, reduced])
  return <><span aria-hidden="true">{metres(reduced ? value : shown, digits)}</span><span className="sr-only">{metres(value, digits)}</span></>
}

export function Photograph({ photo, className = '', eager = false }: { photo: string; className?: string; eager?: boolean }) {
  const credit = photos[photo]
  return <figure className={'atlas-photo ' + className}>
    <img src={asset('kepek/' + photo + '.webp')} alt={credit.caption} loading={eager ? 'eager' : 'lazy'} decoding="async" />
    <figcaption>
      <span>{credit.caption}</span>
      <a href={credit.source} aria-label={'Kép forrása · ' + credit.creator} target="_blank" rel="noreferrer" title={credit.creator + ' · ' + credit.license}><ExternalLink size={13} /></a>
    </figcaption>
  </figure>
}

export function PanelHeading({ icon, eyebrow, children }: { icon: ReactNode; eyebrow: string; children: ReactNode }) {
  return <div className="panel-heading">
    <p className="overline">{icon}{eyebrow}</p>
    <h2>{children}</h2>
  </div>
}
