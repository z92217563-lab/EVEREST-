import type { Geo } from './core.ts'

export const innerBounds = { north: 28.073, south: 27.902, west: 86.801, east: 87.073 }
export const outerBounds = { north: 28.375, south: 27.59, west: 86.28, east: 87.61 }
export const VERTICAL_SCALE = 1.14
export const DATUM = 3900
export const CENTER = { lat: 27.98812, lon: 86.92498 }
export type Bounds = typeof innerBounds
export type TerrainData = { inner: Uint16Array; outer: Uint16Array }

export function toWorld({ lat, lon }: Geo): [number, number] {
  return [(lon - CENTER.lon) * 98.18, (CENTER.lat - lat) * 111.195]
}
function toRect(bounds: Bounds) {
  const [minX, minZ] = toWorld({ lon: bounds.west, lat: bounds.north })
  const [maxX, maxZ] = toWorld({ lon: bounds.east, lat: bounds.south })
  return { minX, minZ, maxX, maxZ }
}
export const innerRect = toRect(innerBounds)
export const outerRect = toRect(outerBounds)
export const toHeight = (metres: number) => (metres - DATUM) * VERTICAL_SCALE / 1000
const clamp = (n: number, low: number, high: number) => Math.max(low, Math.min(high, n))
const lerp = (a: number, b: number, t: number) => a + (b - a) * t

export function sample(grid: Uint16Array, side: number, rect: typeof innerRect, x: number, z: number) {
  const px = clamp((x - rect.minX) / (rect.maxX - rect.minX) * (side - 1), 0, side - 1)
  const pz = clamp((z - rect.minZ) / (rect.maxZ - rect.minZ) * (side - 1), 0, side - 1)
  const ix = Math.min(Math.floor(px), side - 2)
  const iz = Math.min(Math.floor(pz), side - 2)
  const i = iz * side + ix
  return lerp(lerp(grid[i], grid[i + 1], px - ix), lerp(grid[i + side], grid[i + side + 1], px - ix), pz - iz)
}

export function elevationAt(x: number, z: number, data: TerrainData | null) {
  if (!data) {
    const peak = (px: number, pz: number, height: number, broadness: number) =>
      height * Math.exp(-Math.pow(Math.hypot(x - px, z - pz) / broadness, 1.28))
    const ridges = (Math.sin(x * 2.8 + z * 0.9) * Math.cos(z * 2.15 - x * 0.7) * 0.14
      + Math.sin(x * 6.8 + z * 5.9) * 0.042) * Math.exp(-Math.hypot(x, z) / 36)
    return 3850 + 1000 * (Math.max(
      peak(0, 0, 5, 5.5), peak(0.8, 3, 4.61, 4.3), peak(-3.5, 2.4, 3.96, 3.9),
      peak(-9.6, -3, 3.26, 3.6), peak(5.2, -6, 3.4, 4.3),
    ) + ridges)
  }
  const outerDistance = Math.max(0, innerRect.minX - x, x - innerRect.maxX, innerRect.minZ - z, z - innerRect.maxZ)
  if (outerDistance >= 1.6) return sample(data.outer, 257, outerRect, x, z)
  const near = sample(data.inner, 513, innerRect, x, z)
  if (outerDistance === 0) return near
  const t = outerDistance / 1.6
  return lerp(near, sample(data.outer, 257, outerRect, x, z), t * t * (3 - 2 * t))
}

let sharedLoad: Promise<TerrainData> | undefined
export function loadTerrain(base: string) {
  async function read(name: string, count: number) {
    const response = await fetch(base + 'atlas/' + name)
    if (!response.ok) throw new Error(name)
    const buffer = await response.arrayBuffer()
    if (buffer.byteLength !== count * 2) throw new Error(name + ' méret')
    const reader = new DataView(buffer)
    return Uint16Array.from({ length: count }, (_, index) => reader.getUint16(index * 2, true))
  }
  sharedLoad ??= Promise.all([read('khumbu.bin', 513 ** 2), read('himalaja.bin', 257 ** 2)])
    .then(([inner, outer]) => ({ inner, outer })).catch(error => {
      sharedLoad = undefined
      throw error
    })
  return sharedLoad
}
