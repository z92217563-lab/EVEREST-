"""Rebuild the bundled Terrarium grids. Requires Python 3 and Pillow."""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from math import asinh, floor, hypot, pi, radians, tan
from pathlib import Path
from struct import pack
from urllib.request import Request, urlopen

from PIL import Image

OUTPUT = Path(__file__).resolve().parents[1] / "public" / "atlas"
INNER = (28.073, 27.902, 86.801, 87.073)
OUTER = (28.375, 27.59, 86.28, 87.61)


def mercator(lat, lon, zoom):
    scale = 256 * 2 ** zoom
    return scale * (lon + 180) / 360, scale * (1 - asinh(tan(radians(lat))) / pi) / 2


def load_tile(tile):
    zoom, x, y = tile
    url = f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{zoom}/{x}/{y}.png"
    req = Request(url, headers={"User-Agent": "Everest-Atlasz/2.0 educational application"})
    for attempt in range(3):
        try:
            with urlopen(req, timeout=25) as response:
                image = Image.open(BytesIO(response.read())).convert("RGB")
                return (x, y), image.load()
        except (OSError, ValueError):
            if attempt == 2:
                raise


def grid(bounds, zoom, points, file):
    north, south, west, east = bounds
    x0, y0 = mercator(north, west, zoom)
    x1, y1 = mercator(south, east, zoom)
    keys = [(zoom, x, y) for x in range(floor(x0 / 256), floor((x1 + 2) / 256) + 1)
            for y in range(floor(y0 / 256), floor((y1 + 2) / 256) + 1)]
    with ThreadPoolExecutor(10) as pool:
        tiles = dict(pool.map(load_tile, keys))

    def elevation(x, y):
        tx, px = divmod(x, 256)
        ty, py = divmod(y, 256)
        red, green, blue = tiles[tx, ty][px, py]
        return red * 256 + green + blue / 256 - 32768

    values = []
    for j in range(points):
        lat = north + (south - north) * j / (points - 1)
        for i in range(points):
            lon = west + (east - west) * i / (points - 1)
            x, y = mercator(lat, lon, zoom)
            xi, yi = floor(x), floor(y)
            dx, dy = x - xi, y - yi
            a = elevation(xi, yi) * (1 - dx) + elevation(xi + 1, yi) * dx
            b = elevation(xi, yi + 1) * (1 - dx) + elevation(xi + 1, yi + 1) * dx
            values.append(max(0, round(a * (1 - dy) + b * dy)))
    (OUTPUT / file).write_bytes(pack(f"<{len(values)}H", *values))
    print(file, len(values), "mintapont", min(values), max(values))
    return values


def relief(values, size):
    image = Image.new("RGB", (size, size))
    pixels = image.load()
    for j in range(size):
        for i in range(size):
            y = values[j * size + i]
            vx = values[j * size + min(i + 1, size - 1)] - values[j * size + max(0, i - 1)]
            vz = values[min(j + 1, size - 1) * size + i] - values[max(0, j - 1) * size + i]
            shade = max(0, min(1, .24 + (y - 3800) / 7800 + (vx + vz) / 530))
            contour = min(y % 220, 220 - y % 220) < min(31, 6 + hypot(vx, vz) * .24)
            pixels[i, j] = (int(9 + shade * 46 + 7 * contour),
                            int(22 + shade * 83 + 13 * contour),
                            int(34 + shade * 107 + 19 * contour))
    image.save(OUTPUT / "khumbu.webp", quality=87)


if __name__ == "__main__":
    OUTPUT.mkdir(parents=True, exist_ok=True)
    relief(grid(INNER, 13, 513, "khumbu.bin"), 513)
    grid(OUTER, 10, 257, "himalaja.bin")
