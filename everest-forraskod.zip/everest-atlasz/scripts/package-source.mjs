import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises'
import { resolve, relative, dirname, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { zipSync } from 'fflate'

const root = fileURLToPath(new URL('../', import.meta.url))
const output = resolve(root, 'public/everest-forraskod.zip')
const roots = ['src', 'public', 'tests', 'scripts', 'README.md', 'index.html', 'package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', '.gitignore']
const files = {}

async function collect(path) {
  const entries = await readdir(path, { withFileTypes: true })
  await Promise.all(entries.map(entry => {
    const file = resolve(path, entry.name)
    return entry.isDirectory() ? collect(file) : entry.isFile() ? add(file) : undefined
  }))
}
async function add(path) {
  if (path === output) return
  const key = 'everest-atlasz/' + relative(root, path).split(sep).join('/')
  files[key] = await readFile(path)
}

for (const path of roots) {
  const file = resolve(root, path)
  if (['src', 'public', 'tests', 'scripts'].includes(path)) await collect(file)
  else await add(file)
}
await mkdir(dirname(output), { recursive: true })
const sorted = Object.fromEntries(Object.entries(files).sort(([a], [b]) => a.localeCompare(b)))
await writeFile(output, zipSync(sorted, { level: 6, mtime: new Date('2024-01-01T12:00:00Z') }))
