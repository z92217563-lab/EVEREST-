import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import {
  atmosphere, altitudeBand, chapters, comparisons, elevationStops, exhibits, idleTour, OXYGEN_FRACTION,
  placeById, places, questions, route, scoreQuiz, SEA_PRESSURE, SUMMIT, timeline, tourReducer, weatherPresets,
} from '../src/core.ts'
import { elevationAt, toWorld } from '../src/terrain.ts'

const bytes = name => readFileSync(new URL('../public/' + name, import.meta.url))
const readHeightGrid = name => {
  const buffer = bytes('atlas/' + name)
  return Uint16Array.from({ length: buffer.length / 2 }, (_, i) => buffer.readUInt16LE(i * 2))
}

test('standard atmosphere pressure, oxygen and temperature at the reference altitudes', () => {
  const sea = atmosphere(0)
  assert.equal(sea.pressure, SEA_PRESSURE)
  assert.equal(sea.temperature, 15)
  assert.equal(sea.oxygen, SEA_PRESSURE * OXYGEN_FRACTION)
  const summit = atmosphere(SUMMIT)
  assert.ok(summit.pressure > 30 && summit.pressure < 33)
  assert.ok(summit.oxygen > 6 && summit.oxygen < 7)
  assert.ok(summit.temperature > -43 && summit.temperature < -42)
  assert.equal(altitudeBand(8000).title, 'Halálzóna')
  assert.notEqual(altitudeBand(7999).title, 'Halálzóna')
  for (let i = 1; i <= 8; i += 1) assert.ok(atmosphere(i * 1000).pressure < atmosphere((i - 1) * 1000).pressure)
})

test('the atlas references valid places and bundled licensed photos', () => {
  const credits = JSON.parse(bytes('kepek/attribution.json').toString('utf8'))
  assert.equal(places.length, new Set(places.map(place => place.id)).size)
  for (const id of [...elevationStops, ...route, ...chapters.map(item => item.place)]) assert.ok(placeById[id], id)
  for (const photo of new Set([...places, ...timeline, ...exhibits].map(item => item.photo))) {
    assert.ok(existsSync(new URL('../public/kepek/' + photo + '.webp', import.meta.url)), photo)
    assert.ok(credits[photo]?.license, photo)
    assert.ok(credits[photo]?.creator, photo)
  }
  assert.equal(weatherPresets.length, 6)
  assert.ok(elevationStops.every((id, i) => i === 0 || placeById[id].altitude < placeById[elevationStops[i - 1]].altitude))
})

test('terrain samples cover the local summit and surrounding valleys', () => {
  const data = { inner: readHeightGrid('khumbu.bin'), outer: readHeightGrid('himalaja.bin') }
  assert.equal(data.inner.length, 513 ** 2)
  assert.equal(data.outer.length, 257 ** 2)
  assert.ok(elevationAt(...toWorld(placeById.summit.geo), data) > 8550)
  assert.ok(elevationAt(...toWorld(placeById.base.geo), data) > 5100)
  assert.ok(elevationAt(...toWorld(placeById.base.geo), data) < 5550)
  assert.ok(elevationAt(35, 18, data) > 2000)
})

test('guided tour pauses, resumes, seeks and ends with the quiz', () => {
  let tour = tourReducer(idleTour, { type: 'start' })
  assert.equal(tour.chapter, 0)
  tour = tourReducer(tour, { type: 'tick', delta: 4000 })
  tour = tourReducer(tour, { type: 'toggle' })
  assert.equal(tourReducer(tour, { type: 'tick', delta: 30_000 }).elapsed, 4000)
  tour = tourReducer(tour, { type: 'toggle' })
  tour = tourReducer(tour, { type: 'tick', delta: chapters[0].duration - 4000 })
  assert.equal(tour.chapter, 1)
  assert.equal(tour.elapsed, 0)
  tour = tourReducer(tour, { type: 'seek', index: 0 })
  assert.equal(tourReducer(tour, { type: 'seek', index: -1 }).chapter, 0)
  tour = tourReducer(tour, { type: 'seek', index: chapters.length - 1 })
  tour = tourReducer(tour, { type: 'tick', delta: chapters.at(-1).duration })
  assert.equal(tour.finished, true)
  assert.equal(tour.playing, false)
  assert.equal(tour.chapter, -1)
})

test('quiz score and comparisons reflect every displayed entry', () => {
  assert.equal(questions.length, 10)
  assert.equal(scoreQuiz(questions.map(item => item.correct)), 10)
  assert.equal(scoreQuiz(questions.map(item => (item.correct + 1) % item.options.length)), 0)
  assert.equal(scoreQuiz([questions[0].correct, null, questions[2].correct]), 2)
  assert.equal(comparisons.length, 6)
  assert.equal(comparisons.find(item => item.id === 'everest').height, SUMMIT)
  assert.ok(comparisons.every((item, i) => i === 0 || comparisons[i - 1].height < item.height))
})
